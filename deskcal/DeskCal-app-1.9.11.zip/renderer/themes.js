// DeskCal 테마 모음 — 기본 테마 + Linaverse 12지신 컨셉 테마
// 각 테마는 몇 가지 기본 색만 정하고, 나머지(선·면·흐린 글자)는 자동으로 계산합니다.
// 사용자가 고른 배경색·글자색·강조색은 테마 위에 덮어씁니다.
(function (root) {
  // ---------------------------------------------------------------- 색 계산 도우미
  const hex = (h) => {
    let s = String(h || '#000').replace('#', '');
    if (s.length === 3) s = s.split('').map((c) => c + c).join('');
    const n = parseInt(s.slice(0, 6), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  };
  const toHex = (r, g, b) => '#' + [r, g, b].map((v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0')).join('');
  const mix = (a, b, t) => { const x = hex(a), y = hex(b); return toHex(x[0] + (y[0] - x[0]) * t, x[1] + (y[1] - x[1]) * t, x[2] + (y[2] - x[2]) * t); };
  const lum = (h) => { const [r, g, b] = hex(h); return (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255; };
  const rgba = (h, a) => { const [r, g, b] = hex(h); return `rgba(${r},${g},${b},${a})`; };
  const isHex = (v) => /^#?[0-9a-f]{6}$/i.test(String(v || '').trim());

  // 기본 색 몇 개 → 화면에 쓰는 모든 색
  function build(p) {
    const dark = p.dark != null ? p.dark : lum(p.bg) < 0.45;
    const text = p.text, bg = p.bg;
    const panel = p.panel || mix(bg, dark ? '#ffffff' : '#ffffff', dark ? 0.03 : 0.55);
    const pop = p.pop || (dark ? mix(bg, '#ffffff', 0.07) : '#FFFFFF');
    const ink = p.ink || text;
    return {
      dark,
      vars: {
        '--bg': p.bg2 ? `linear-gradient(180deg, ${bg}, ${p.bg2})` : bg,
        '--bg-solid': bg,
        '--panel-solid': panel,
        '--popover': pop,
        '--surface': 'transparent',
        '--surface-2': rgba(ink, dark ? 0.05 : 0.05),
        '--surface-3': rgba(ink, dark ? 0.095 : 0.09),
        '--line': rgba(ink, dark ? 0.085 : 0.11),
        '--line-strong': rgba(ink, dark ? 0.16 : 0.2),
        '--text': text,
        '--sub': p.sub || mix(text, bg, dark ? 0.36 : 0.28),
        '--dim': p.dim || mix(text, bg, dark ? 0.58 : 0.5),
        '--sun': p.sun || (dark ? '#E58378' : '#C8483E'),
        '--sat': p.sat || (dark ? '#86A9D6' : '#3A69B0'),
        '--danger': dark ? '#E8877C' : '#C0443A',
        '--ok': dark ? '#8DBE86' : '#4E8A47',
        '--warn': dark ? '#D9B25F' : '#A87B1F',
        '--shadow': dark ? '0 10px 28px rgba(0,0,0,.45)' : `0 10px 26px ${rgba(mix(text, bg, 0.3), 0.14)}`,
        '--chip-ink': text,
        '--glass': 'none',
        'color-scheme': dark ? 'dark' : 'light'
      }
    };
  }

  // ---------------------------------------------------------------- 장식 그림 (작은 SVG)
  const S = (body) => `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">${body}</svg>`;
  const MOTIF = {
    cheese: S('<path d="M3 17 L20 8 L21 18 Z" fill="#F6CE55" stroke="#C9952A" stroke-width="1.2" stroke-linejoin="round"/><circle cx="14" cy="14.5" r="1.6" fill="#E3AE3A"/><circle cx="18" cy="15.5" r="1" fill="#E3AE3A"/><circle cx="10" cy="16" r="1" fill="#E3AE3A"/>'),
    book: S('<rect x="5" y="4" width="13" height="16" rx="2" fill="#9C86D8"/><rect x="7" y="4" width="2" height="16" fill="#7F68C2"/><rect x="11" y="8" width="5" height="1.5" rx=".7" fill="#fff" opacity=".8"/>'),
    star: S('<path d="M12 3.5l2.5 5.2 5.7.8-4.1 4 1 5.6L12 16.4 6.9 19.1l1-5.6-4.1-4 5.7-.8z" fill="#F7CF5C" stroke="#D8A73A" stroke-width=".8" stroke-linejoin="round"/>'),
    sparkle: S('<path d="M12 2c.8 5 2.2 6.6 7 7.5-4.8.9-6.2 2.5-7 7.5-.8-5-2.2-6.6-7-7.5 4.8-.9 6.2-2.5 7-7.5z" fill="#FFFFFF" stroke="#BFE7D6" stroke-width=".8"/>'),
    clover: S('<circle cx="12" cy="7.5" r="4" fill="#79B865"/><circle cx="7.5" cy="13" r="4" fill="#79B865"/><circle cx="16.5" cy="13" r="4" fill="#79B865"/><path d="M12 13 Q13 18 16 21" stroke="#5E9A4C" stroke-width="1.6" fill="none" stroke-linecap="round"/>'),
    cloud: S('<path d="M7 18h10.5a4 4 0 0 0 .4-8 5.5 5.5 0 0 0-10.6-1A4.5 4.5 0 0 0 7 18z" fill="#FFFFFF" stroke="#C9D7EA" stroke-width="1.1"/>'),
    milk: S('<path d="M9 3h6v3l2 3v11a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 7 20V9l2-3z" fill="#FFFFFF" stroke="#B9C7D6" stroke-width="1.1"/><rect x="7" y="12" width="10" height="4" fill="#8CC5F0"/>'),
    tangerine: S('<circle cx="12" cy="13.5" r="7" fill="#F7962E"/><circle cx="9.5" cy="11" r="1.6" fill="#FFC27A" opacity=".8"/><path d="M12 6.5 Q15 3 18 4.5 Q15.5 7.5 12 6.5z" fill="#5FA34B"/>'),
    leaf: S('<path d="M5 19 C5 9 11 4 20 4 C20 13 15 19 5 19z" fill="#6DAA55"/><path d="M5 19 L15 9" stroke="#4E8A3D" stroke-width="1.2" stroke-linecap="round"/>'),
    stripe: S('<path d="M4 7 Q12 4 20 7" stroke="#3A2A1C" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".55"/><path d="M4 13 Q12 10 20 13" stroke="#3A2A1C" stroke-width="2.2" fill="none" stroke-linecap="round" opacity=".55"/>'),
    petal: S('<g fill="#F6B3C6" stroke="#E8869F" stroke-width=".7"><ellipse cx="12" cy="6.5" rx="3" ry="4"/><ellipse cx="17.2" cy="10.3" rx="3" ry="4" transform="rotate(72 17.2 10.3)"/><ellipse cx="15.2" cy="16.6" rx="3" ry="4" transform="rotate(144 15.2 16.6)"/><ellipse cx="8.8" cy="16.6" rx="3" ry="4" transform="rotate(216 8.8 16.6)"/><ellipse cx="6.8" cy="10.3" rx="3" ry="4" transform="rotate(288 6.8 10.3)"/></g><circle cx="12" cy="12" r="1.8" fill="#F7D46A"/>'),
    carrot: S('<path d="M15 8 L5 20 L17 10z" fill="#F28C38" stroke="#D8701F" stroke-width=".9" stroke-linejoin="round"/><path d="M15 8 Q15 3 17 2 M16 9 Q20 6 22 7 M16 8.5 Q19 4 21 3.5" stroke="#5FA34B" stroke-width="1.6" fill="none" stroke-linecap="round"/>'),
    heart: S('<path d="M12 20s-7.5-4.6-7.5-10A4.3 4.3 0 0 1 12 7.4 4.3 4.3 0 0 1 19.5 10c0 5.4-7.5 10-7.5 10z" fill="#F38BA8"/>'),
    pearl: S('<circle cx="12" cy="12" r="6.5" fill="#F4F1FA" stroke="#C9C2DF" stroke-width="1"/><circle cx="9.8" cy="9.6" r="1.8" fill="#FFFFFF"/>'),
    teacup: S('<path d="M5 9h12v4a6 6 0 0 1-12 0z" fill="#FFFFFF" stroke="#8FA672" stroke-width="1.2"/><path d="M17 10.5h1.5a2 2 0 0 1 0 4H16.5" stroke="#8FA672" stroke-width="1.2" fill="none"/><rect x="6" y="9.5" width="10" height="2.4" fill="#9CBF6A"/><path d="M3 20h16" stroke="#8FA672" stroke-width="1.4" stroke-linecap="round"/><path d="M9 3c-1 1.5 1 2 0 3.5M13 3c-1 1.5 1 2 0 3.5" stroke="#B6C7A3" stroke-width="1.1" fill="none" stroke-linecap="round"/>'),
    drop: S('<path d="M12 3 C12 3 6 10.5 6 14.5a6 6 0 0 0 12 0C18 10.5 12 3 12 3z" fill="#A9D3C0"/><circle cx="10" cy="14" r="1.4" fill="#fff" opacity=".8"/>'),
    ribbon: S('<path d="M12 11 L5 6.5 V15.5z M12 11 L19 6.5 V15.5z" fill="#B79BF0" stroke="#9378D6" stroke-width=".9" stroke-linejoin="round"/><circle cx="12" cy="11" r="2" fill="#9378D6"/><path d="M11 12.5 L8.5 20 M13 12.5 L15.5 20" stroke="#9378D6" stroke-width="1.6" stroke-linecap="round"/>'),
    flag: S('<path d="M2 5 Q12 9 22 5" stroke="#B0A3C9" stroke-width="1" fill="none"/><path d="M5 6.3 L7.5 13 L10 7.6z" fill="#F4A6C8"/><path d="M10.6 7.7 L12.5 14.5 L14.4 7.7z" fill="#9FD3F2"/><path d="M15 7.6 L17 13 L19.4 6.3z" fill="#F8D676"/>'),
    moon: S('<path d="M15.5 3.5A8.5 8.5 0 1 0 20.5 17 7 7 0 0 1 15.5 3.5z" fill="#FBE7A1" stroke="#E5C66A" stroke-width=".9"/>'),
    banana: S('<path d="M4 7 C6 16 13 20 20 17 C14 17 8 13 6.5 6z" fill="#F7D24A" stroke="#D3A82A" stroke-width="1" stroke-linejoin="round"/><path d="M4 7 L5.4 5.6 L6.5 6" stroke="#6B5323" stroke-width="1.4" fill="none" stroke-linecap="round"/>'),
    palm: S('<path d="M12 21 V11" stroke="#7A5A34" stroke-width="1.8" stroke-linecap="round"/><path d="M12 11 C8 7 4 8 2.5 10 C6 9 9 10 12 11z M12 11 C16 7 20 8 21.5 10 C18 9 15 10 12 11z M12 11 C10 6 11 3 13 2 C12 5 12.5 8 12 11z" fill="#59A35B"/>'),
    sun: S('<circle cx="12" cy="12" r="4.5" fill="#FFC94A"/><g stroke="#F6A93A" stroke-width="1.8" stroke-linecap="round"><path d="M12 3v2.5M12 18.5V21M3 12h2.5M18.5 12H21M5.6 5.6l1.8 1.8M16.6 16.6l1.8 1.8M5.6 18.4l1.8-1.8M16.6 7.4l1.8-1.8"/></g>'),
    egg: S('<path d="M5 13 C3 8 9 4 13 6 C18 4 22 9 19 13 C20 18 13 20 10 18 C6 19 4 16 5 13z" fill="#FFFFFF" stroke="#E5DCCB" stroke-width="1"/><circle cx="12" cy="12" r="3.4" fill="#FFC531"/><circle cx="11" cy="11" r="1" fill="#fff" opacity=".7"/>'),
    bread: S('<path d="M4 12a8 5 0 0 1 16 0v6a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z" fill="#E7A65A" stroke="#C47F35" stroke-width="1"/><path d="M8 10 l1.5 3M12 9.5 l1.5 3M16 10 l1.5 3" stroke="#F7CF95" stroke-width="1.3" stroke-linecap="round"/>'),
    paw: S('<g fill="#C98E5B"><ellipse cx="12" cy="15.5" rx="4.5" ry="3.8"/><circle cx="6.5" cy="10" r="2"/><circle cx="10" cy="6.8" r="2"/><circle cx="14" cy="6.8" r="2"/><circle cx="17.5" cy="10" r="2"/></g>'),
    bone: S('<path d="M7 9.5a2.4 2.4 0 1 1 2.4-2.9L14.6 11.7a2.4 2.4 0 1 1 2.9 2.4 2.4 2.4 0 1 1-2.4 2.9L9.9 11.9A2.4 2.4 0 1 1 7 9.5z" fill="#FFFFFF" stroke="#D9C7AE" stroke-width="1"/>'),
    ball: S('<circle cx="12" cy="12" r="7" fill="#7CC0E8"/><path d="M5.5 9.5 Q12 13 18.5 9.5 M6 15 Q12 11.5 18 15" stroke="#FFFFFF" stroke-width="1.4" fill="none"/>'),
    strawberry: S('<path d="M12 21 C6 18 4 13 5.5 9.5 C8 8 16 8 18.5 9.5 C20 13 18 18 12 21z" fill="#F0566E"/><path d="M7 8.5 L9.5 6 L12 8 L14.5 6 L17 8.5 L12 10z" fill="#5FA34B"/><g fill="#FFE3A3"><circle cx="9" cy="12.5" r=".7"/><circle cx="12" cy="13" r=".7"/><circle cx="15" cy="12.5" r=".7"/><circle cx="10.5" cy="16" r=".7"/><circle cx="13.5" cy="16" r=".7"/></g>'),
    donut: S('<circle cx="12" cy="12" r="8" fill="#E8B07A"/><circle cx="12" cy="12" r="6.6" fill="#F59BB2"/><circle cx="12" cy="12" r="2.6" fill="#FFF5F7"/><g stroke-width="1.2" stroke-linecap="round"><path d="M8 8.5l1 .6" stroke="#FFE07A"/><path d="M15.5 8l.8-.9" stroke="#8ED0F2"/><path d="M16 15l1 .5" stroke="#FFFFFF"/><path d="M8.5 15.5l-.6 1" stroke="#9FDA8E"/></g>'),
    dot: S('<circle cx="12" cy="12" r="4" fill="#F7A9B9"/>'),
    maple: S('<path d="M12 2l1.8 4.2 3.4-1.6-1 3.9 4.3.3-3.2 3 1.6 1.4-4.4.9.6 3.4L12 15.6 8.9 17.5l.6-3.4-4.4-.9 1.6-1.4-3.2-3 4.3-.3-1-3.9 3.4 1.6z" fill="#E8692C"/><path d="M12 15.6V22" stroke="#B84E1C" stroke-width="1.3" stroke-linecap="round"/>'),
    acorn: S('<path d="M6 10h12a6 7 0 0 1-12 0z" fill="#C98B4E"/><path d="M5 10.5c0-3 3-5 7-5s7 2 7 5z" fill="#7A5232"/><path d="M12 5.5V3" stroke="#5E3E24" stroke-width="1.6" stroke-linecap="round"/>'),
    snowflake: S('<g stroke="#8DB8EA" stroke-width="1.8" stroke-linecap="round"><path d="M12 2v20M3.3 7l17.4 10M3.3 17l17.4-10"/><path d="M9.5 3.8 12 6l2.5-2.2M9.5 20.2 12 18l2.5 2.2"/></g>'),
    pumpkin: S('<ellipse cx="12" cy="14" rx="8.5" ry="7" fill="#F28A2B"/><path d="M12 7v14M8 7.8c-2 3-2 9.5 0 12.4M16 7.8c2 3 2 9.5 0 12.4" stroke="#D86E14" stroke-width="1.1" fill="none"/><path d="M12 7c0-2 1-3 2.5-3.5" stroke="#5E8C3A" stroke-width="1.8" fill="none" stroke-linecap="round"/>'),
    bat: S('<path d="M12 9c1.5 0 2 1 2 2 2-2 5-2 8-1-2 1-2.5 3-2 5-1.5-1-3-1-4.5 0-.5-1-2-1.5-3.5-1.5S9 14 8.5 15c-1.5-1-3-1-4.5 0 .5-2 0-4-2-5 3-1 6-1 8 1 0-1 .5-2 2-2z" fill="#4A3B5C"/>'),
    ghost: S('<path d="M5 20V11a7 7 0 0 1 14 0v9l-2.3-1.6L14.3 20 12 18.4 9.7 20l-2.4-1.6z" fill="#FFFFFF" stroke="#C9C2DA" stroke-width="1"/><circle cx="9.6" cy="11" r="1.1" fill="#3B3346"/><circle cx="14.4" cy="11" r="1.1" fill="#3B3346"/>'),
    gift: S('<rect x="4" y="10" width="16" height="11" rx="1.5" fill="#D9473E"/><rect x="3" y="7" width="18" height="4" rx="1" fill="#E85B50"/><rect x="11" y="7" width="2.4" height="14" fill="#F6D35B"/><path d="M12 7c-2-3-5-3-5-1s3 1 5 1c2 0 5 1 5-1s-3-2-5 1z" fill="none" stroke="#F6D35B" stroke-width="1.5"/>'),
    xtree: S('<path d="M12 2 5 12h3.5L4 18h16l-4.5-6H19z" fill="#3E9A5A"/><rect x="10.5" y="18" width="3" height="3.5" fill="#8A5A35"/><circle cx="9.5" cy="13.5" r="1" fill="#F2C94C"/><circle cx="14.5" cy="15.5" r="1" fill="#E85B50"/><circle cx="12" cy="9" r="1" fill="#E85B50"/>'),
    firework: S('<g stroke-width="1.8" stroke-linecap="round"><path d="M12 3v4M12 17v4M3 12h4M17 12h4" stroke="#F2A51A"/><path d="M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M5.6 18.4l2.8-2.8M15.6 8.4l2.8-2.8" stroke="#E86AA0"/></g><circle cx="12" cy="12" r="1.8" fill="#8E7CE8"/>'),
    persimmon: S('<circle cx="12" cy="13.5" r="7.5" fill="#F07A2A"/><path d="M8 7.5c1.5 1 2.5 1 4 0 1.5 1 2.5 1 4 0-.5 2-2 3-4 3s-3.5-1-4-3z" fill="#5E8C3A"/><circle cx="9.5" cy="12" r="1.5" fill="#FFB27A" opacity=".7"/>'),
    fullmoon: S('<circle cx="12" cy="12" r="8.5" fill="#FBE18A" stroke="#EDC24F" stroke-width="1"/><circle cx="9" cy="10" r="1.6" fill="#EFCF6A"/><circle cx="14.5" cy="14" r="1.1" fill="#EFCF6A"/>'),
    starfish: S('<path d="M12 2.5l2.3 6.3 6.6.3-5.2 4.1 1.9 6.4L12 15.9l-5.6 3.7 1.9-6.4-5.2-4.1 6.6-.3z" fill="#F69A7C" stroke="#E67455" stroke-width=".8" stroke-linejoin="round"/>'),
    watermelon: S('<path d="M3 9a9 9 0 0 0 18 0z" fill="#5FAE58"/><path d="M4.6 9a7.4 7.4 0 0 0 14.8 0z" fill="#F2556D"/><g fill="#3A2A2A"><circle cx="9" cy="12" r=".7"/><circle cx="12" cy="13.6" r=".7"/><circle cx="15" cy="12" r=".7"/></g>'),
    lantern: S('<path d="M12 2v2.5" stroke="#B98A2E" stroke-width="1.4"/><rect x="9" y="4" width="6" height="2" rx=".6" fill="#B98A2E"/><ellipse cx="12" cy="12" rx="6.5" ry="6" fill="#E04A3A"/><path d="M12 6v12M8.3 7.2c-1.5 3-1.5 6.6 0 9.6M15.7 7.2c1.5 3 1.5 6.6 0 9.6" stroke="#B83426" stroke-width=".9" fill="none"/><rect x="9" y="17.6" width="6" height="1.8" rx=".6" fill="#B98A2E"/><path d="M12 19.4v2.6" stroke="#F2C94C" stroke-width="1.6" stroke-linecap="round"/>')
  };
  const svgUrl = (svg) => `url("data:image/svg+xml;utf8,${encodeURIComponent(svg)}")`;

  // ---------------------------------------------------------------- 기본 테마
  const BASIC = [
    // 다크
    { id: 'midnight', group: 'dark', name: '잉크', desc: '따뜻한 먹색', accent: '#D27A4A', p: { bg: '#141414', bg2: '#121212', panel: '#1A1A1A', pop: '#1E1E1E', text: '#ECE9E3', sub: '#A39F97', dim: '#6F6B64', sun: '#E07A6E', sat: '#7FA3D1' } },
    { id: 'aurora', group: 'dark', name: '포레스트', desc: '짙은 이끼색', accent: '#8DBE86', p: { bg: '#141A16', bg2: '#121814', panel: '#19211C', pop: '#1C251F', text: '#E7EBE4', sub: '#A0AA9F', dim: '#6C766C', sun: '#E08070', sat: '#8BAECB' } },
    { id: 'navy', group: 'dark', name: '미드나잇 블루', desc: '깊은 밤 남색', accent: '#7FA7E8', p: { bg: '#0F1626', bg2: '#0C1220', panel: '#141D30', text: '#E6EAF2', sub: '#9AA6BD', dim: '#64708A' } },
    { id: 'mocha', group: 'dark', name: '모카', desc: '커피 한 잔 같은 브라운', accent: '#D49A6A', p: { bg: '#1B1613', bg2: '#171310', panel: '#221C18', text: '#EFE6DD', sub: '#B3A497', dim: '#7D6F63' } },
    { id: 'plum', group: 'dark', name: '플럼', desc: '차분한 자두빛 보라', accent: '#C58BE0', p: { bg: '#1A1420', bg2: '#16111B', panel: '#221A2A', text: '#EEE6F3', sub: '#AE9DBC', dim: '#786985' } },
    { id: 'deepsea', group: 'dark', name: '딥 오션', desc: '깊은 바다 청록', accent: '#4FB3A9', p: { bg: '#0E1A1C', bg2: '#0B1517', panel: '#132326', text: '#E2EFEF', sub: '#94AEAF', dim: '#5E7778' } },
    { id: 'graphite', group: 'dark', name: '그라파이트', desc: '군더더기 없는 회색', accent: '#8AB4F8', p: { bg: '#1C1E22', bg2: '#191B1E', panel: '#23262B', text: '#E8EAED', sub: '#A2A7AF', dim: '#6C727B' } },
    { id: 'oled', group: 'dark', name: '올 블랙', desc: '완전한 검정 (OLED)', accent: '#F5C451', p: { bg: '#000000', panel: '#0A0A0A', pop: '#141414', text: '#F2F2F2', sub: '#A6A6A6', dim: '#6B6B6B' } },
    { id: 'neon', group: 'dark', name: '네온 나이트', desc: '보랏빛 밤 + 핑크 포인트', accent: '#FF5FA8', p: { bg: '#0F0C1E', bg2: '#140F28', panel: '#171230', text: '#ECE8FF', sub: '#A69FCC', dim: '#6D6696', sat: '#7FB4FF', sun: '#FF7A9C' } },
    { id: 'hc', group: 'dark', name: '고대비', desc: '글자가 가장 또렷하게', accent: '#FFD400', p: { bg: '#000000', panel: '#000000', pop: '#111111', text: '#FFFFFF', sub: '#E6E6E6', dim: '#C2C2C2', sun: '#FF8A80', sat: '#9CC7FF', ink: '#FFFFFF' } },
    { id: 'wine', group: 'dark', name: '와인', desc: '깊은 버건디', accent: '#E0848F', p: { bg: '#1C1315', bg2: '#181012', panel: '#241A1C', pop: '#291E21', text: '#F1E6E7', sub: '#B39EA1', dim: '#7C686B', sun: '#F08A8A', sat: '#93A9D8' } },
    { id: 'starry', group: 'dark', name: '별밤', desc: '남보랏빛 밤하늘 + 별빛 노랑', accent: '#F2C46D', p: { bg: '#11142A', bg2: '#0E1124', panel: '#181C36', pop: '#1D213D', text: '#E9EAF6', sub: '#A3A7C7', dim: '#6D7192', sun: '#F08E8E', sat: '#8DB2F2' } },
    // 라이트
    { id: 'paper', group: 'light', name: '페이퍼', desc: '미색 종이', accent: '#D27A4A', p: { bg: '#F4F1EA', bg2: '#F1EDE5', panel: '#FBF9F5', text: '#24211C', sub: '#6B655C', dim: '#9D978D', sun: '#C24A3E', sat: '#3A69B0' } },
    { id: 'snow', group: 'light', name: '스노우', desc: '깨끗한 흰색', accent: '#3B6FE0', p: { bg: '#FAFAFA', panel: '#FFFFFF', text: '#1D1F23', sub: '#5F6670', dim: '#9AA0A8' } },
    { id: 'latte', group: 'light', name: '라떼', desc: '부드러운 베이지', accent: '#B9773F', p: { bg: '#F3EBE1', bg2: '#EFE5D9', panel: '#FAF5EF', text: '#3A2E25', sub: '#6E5D50', dim: '#A08F81' } },
    { id: 'sage', group: 'light', name: '세이지', desc: '은은한 풀빛', accent: '#5E8C61', p: { bg: '#EEF2EA', panel: '#F7F9F4', text: '#26302A', sub: '#5E6B61', dim: '#95A198' } },
    { id: 'lavender', group: 'light', name: '라벤더 미스트', desc: '연보라 안개', accent: '#8A6FD1', p: { bg: '#F2EFF8', panel: '#FAF8FD', text: '#2E2A3A', sub: '#6C6680', dim: '#A39DB5' } },
    { id: 'peach', group: 'light', name: '피치', desc: '복숭아빛 따뜻함', accent: '#D46E55', p: { bg: '#FBEFE8', panel: '#FFF8F4', text: '#3B2A25', sub: '#6E5750', dim: '#A8918A' } },
    { id: 'sky', group: 'light', name: '스카이', desc: '맑은 하늘색', accent: '#3D8BD9', p: { bg: '#EBF3FA', panel: '#F7FBFE', text: '#1F2D3A', sub: '#5A6B7B', dim: '#93A3B2' } },
    { id: 'nordic', group: 'light', name: '노르딕', desc: '차가운 회청색', accent: '#5B7A99', p: { bg: '#ECEFF3', panel: '#F6F8FA', text: '#262B33', sub: '#616B78', dim: '#9AA3AE' } },
    { id: 'pastel', group: 'light', name: '파스텔', desc: '분홍·보라 그라데이션', accent: '#C9789E', p: { bg: '#F8F1EE', bg2: '#F1ECF4', panel: '#FCF8F6', text: '#3A2E36', sub: '#76646F', dim: '#A8979F', sun: '#D0606E', sat: '#5B7FC0' } },
    { id: 'mono', group: 'light', name: '모노', desc: '흑백 미니멀', accent: '#111111', p: { bg: '#FFFFFF', panel: '#FFFFFF', text: '#111111', sub: '#555555', dim: '#999999', sun: '#111111', sat: '#111111' } },
    { id: 'butter', group: 'light', name: '버터 크림', desc: '포근한 노란 크림', accent: '#C9952A', p: { bg: '#FBF5E3', bg2: '#F8F0DA', panel: '#FFFBF0', text: '#3A3222', sub: '#7A6E55', dim: '#AEA28A', sun: '#C8503F', sat: '#4A72B0' } },
    { id: 'mint', group: 'light', name: '민트 소다', desc: '시원한 민트빛', accent: '#2E9C82', p: { bg: '#EAF6F2', bg2: '#E3F2EE', panel: '#F6FCFA', text: '#21352F', sub: '#5F7871', dim: '#94A8A2', sun: '#C8503F', sat: '#3C72B4' } },
  ];

  // ---------------------------------------------------------------- Linaverse 12지신 컨셉 테마 (낮·밤)
  const LINA = [
    { char: 'rat', name: '치즈 도서관', story: '책 사이에 치즈를 숨겨 두는 꼼꼼한 사서 쥐', motifs: ['cheese', 'book', 'star'],
      day: { bg: '#F4F0FA', bg2: '#F7F2E4', panel: '#FBF9FE', text: '#3A3248', accent: '#BD8A14' },
      night: { bg: '#1D1A28', bg2: '#1A1722', panel: '#252134', text: '#EEE9F7', accent: '#F2C94C' } },
    { char: 'ox', name: '목장의 아침', story: '클로버 들판에서 우유 한 병으로 하루를 시작하는 소', motifs: ['clover', 'cloud', 'milk'],
      day: { bg: '#F5F4EA', bg2: '#EEF3E4', panel: '#FFFEF8', text: '#2F3328', accent: '#5F9A4C' },
      night: { bg: '#161B16', bg2: '#131813', panel: '#1D231D', text: '#ECEFE6', accent: '#8BC27A' } },
    { char: 'tiger', name: '귤빛 숲', story: '귤나무 숲을 지키는 줄무늬 꼬마 호랑이', motifs: ['tangerine', 'leaf', 'stripe'],
      day: { bg: '#FFF3E6', bg2: '#FDEBD6', panel: '#FFFAF4', text: '#3D2A1C', accent: '#D46D0E' },
      night: { bg: '#1E1610', bg2: '#1A130D', panel: '#271D15', text: '#F6EADF', accent: '#F5A04A' } },
    { char: 'rabbit', name: '벚꽃 피크닉', story: '벚꽃 아래 당근 도시락을 펼치는 토끼', motifs: ['petal', 'carrot', 'heart'],
      day: { bg: '#FDF0F3', bg2: '#FBE8EE', panel: '#FFF8FA', text: '#3E2A31', accent: '#E06A8E' },
      night: { bg: '#1E1519', bg2: '#1A1216', panel: '#281C21', text: '#F8E9EE', accent: '#F29AB5' } },
    { char: 'dragon', name: '민트 구름 왕국', story: '구름 위 왕국에서 진주를 모으는 아기 용', motifs: ['cloud', 'sparkle', 'pearl'],
      day: { bg: '#ECF7F1', bg2: '#E4F2F2', panel: '#F7FCF9', text: '#213A30', accent: '#2FA077' },
      night: { bg: '#0F1C18', bg2: '#0D1816', panel: '#152621', text: '#E3F3EC', accent: '#5FD3A6' } },
    { char: 'snake', name: '말차 티타임', story: '오후 세 시, 말차 한 잔을 내리는 다정한 뱀', motifs: ['teacup', 'leaf', 'drop'],
      day: { bg: '#EEF3E4', bg2: '#E8EEDB', panel: '#F8FAF2', text: '#2D3523', accent: '#6F8C3C' },
      night: { bg: '#171B12', bg2: '#14170F', panel: '#1F2419', text: '#ECF0E3', accent: '#A4C46A' } },
    { char: 'horse', name: '라벤더 캐러셀', story: '별빛 회전목마를 타고 달리는 꿈꾸는 말', motifs: ['star', 'ribbon', 'flag'],
      day: { bg: '#F3EEFA', bg2: '#EEE6F8', panel: '#FBF8FE', text: '#33284A', accent: '#8B67D1' },
      night: { bg: '#1A1626', bg2: '#161221', panel: '#221D32', text: '#EFE9FA', accent: '#B79BF0' } },
    { char: 'goat', name: '솜사탕 꿈나라', story: '구름 솜사탕을 베고 낮잠 자는 양', motifs: ['cloud', 'moon', 'star'],
      day: { bg: '#EEF4FB', bg2: '#F6EEF6', panel: '#FAFCFF', text: '#26324A', accent: '#CC6690' },
      night: { bg: '#121729', bg2: '#0F1322', panel: '#1A2036', text: '#E8ECF8', accent: '#F3B5CF' } },
    { char: 'monkey', name: '바나나 정글', story: '야자수 사이로 바나나를 나르는 장난꾸러기', motifs: ['banana', 'palm', 'leaf'],
      day: { bg: '#F8F3E2', bg2: '#F0F2DD', panel: '#FFFCF2', text: '#36301C', accent: '#A57C06' },
      night: { bg: '#18170F', bg2: '#15140C', panel: '#211F15', text: '#F2EEDC', accent: '#F0CB4A' } },
    { char: 'rooster', name: '새벽 햇살 베이커리', story: '해 뜨기 전 빵을 굽는 부지런한 닭', motifs: ['sun', 'egg', 'bread'],
      day: { bg: '#FFF8E8', bg2: '#FFF1DA', panel: '#FFFDF6', text: '#3A2D17', accent: '#DA4A35' },
      night: { bg: '#1C1712', bg2: '#18130F', panel: '#251F18', text: '#F7EEDF', accent: '#F2785F' } },
    { char: 'dog', name: '산책 공원', story: '공 하나면 하루가 행복한 산책 친구', motifs: ['paw', 'bone', 'ball'],
      day: { bg: '#F7F1E8', bg2: '#EEF3F6', panel: '#FFFBF5', text: '#35291E', accent: '#B8702E' },
      night: { bg: '#19150F', bg2: '#15120D', panel: '#221D16', text: '#F3EADF', accent: '#E8AE6E' } },
    { char: 'pig', name: '딸기 디저트 카페', story: '딸기 도넛을 굽는 디저트 카페 사장님', motifs: ['strawberry', 'donut', 'dot'],
      day: { bg: '#FFF0F2', bg2: '#FDE8EC', panel: '#FFF8F9', text: '#40262C', accent: '#E35C78' },
      night: { bg: '#1F1417', bg2: '#1B1114', panel: '#2A1B20', text: '#FBE8EC', accent: '#F48CA0' } }
  ];
  const CHAR_NAME = { rat: '쥐', ox: '소', tiger: '호랑이', rabbit: '토끼', dragon: '용', snake: '뱀', horse: '말', goat: '양', monkey: '원숭이', rooster: '닭', dog: '개', pig: '돼지' };

  const THEMES = BASIC.map((t) => ({ ...t, ...build(t.p) }));
  for (const c of LINA) {
    for (const mode of ['day', 'night']) {
      const p = c[mode];
      const b = build(p);
      THEMES.push({
        id: `lina-${c.char}-${mode}`, group: 'linaverse', char: c.char, mode, ck: 'base',
        name: c.name + (mode === 'night' ? ' · 다크' : ''), concept: c.name, story: c.story,
        desc: `${CHAR_NAME[c.char]} · ${mode === 'night' ? '다크' : '라이트'}`, accent: p.accent,
        motifs: c.motifs, ...b
      });
    }
  }
  // ---------------------------------------------------------------- 시즌 컬렉션 (Linaverse 계절·명절 그림)
  const SEASONS = [
    { id: 'spring', kind: '계절', name: '봄 소풍', story: '벚꽃 아래 도시락을 펼친 12지신 소풍날', motifs: ['petal', 'clover', 'heart'], accent: '#E06A8E',
      day: { bg: '#FFF5F6', bg2: '#F3F8EC', panel: '#FFFBFC', text: '#3A2C31' }, night: { bg: '#1F1720', bg2: '#17191A', panel: '#291F2A', text: '#F7EAF0', accent: '#F29AB5' } },
    { id: 'summer', kind: '계절', name: '여름 바캉스', story: '선글라스 끼고 바다로! 튜브·수박·서핑', motifs: ['starfish', 'watermelon', 'sun'], accent: '#1A8FB8',
      day: { bg: '#EEF8FC', bg2: '#FFF7E6', panel: '#F9FDFF', text: '#1E3442' }, night: { bg: '#0D1B26', bg2: '#0B1820', panel: '#132634', text: '#E3F2FA', accent: '#4FC3E8' } },
    { id: 'autumn', kind: '계절', name: '가을 나들이', story: '베레모 쓰고 단풍길 산책, 도토리·감 따기', motifs: ['maple', 'acorn', 'leaf'], accent: '#C9561A',
      day: { bg: '#FFF4E8', bg2: '#FBEBD9', panel: '#FFFAF4', text: '#3E2A1B' }, night: { bg: '#1E150F', bg2: '#19120C', panel: '#281D15', text: '#F6E9DC', accent: '#F08A4B' } },
    { id: 'winter', kind: '계절', name: '겨울 눈꽃', story: '목도리 두르고 코코아 한 잔, 눈사람 만들기', motifs: ['snowflake', 'cloud', 'heart'], accent: '#3F78CF',
      day: { bg: '#F1F6FD', bg2: '#E9F0FA', panel: '#FAFCFF', text: '#22314A' }, night: { bg: '#111A2B', bg2: '#0E1524', panel: '#172238', text: '#E6EEFA', accent: '#7FB0F5' } },
    { id: 'halloween', kind: '행사', name: '할로윈 나이트', story: '마녀 모자 쓰고 사탕 바구니 들고 트릭 오어 트릿!', motifs: ['pumpkin', 'bat', 'ghost'], accent: '#E0701A',
      day: { bg: '#FFF4E6', bg2: '#F4EEFA', panel: '#FFFAF3', text: '#33243F' }, night: { bg: '#1C1428', bg2: '#170F21', panel: '#241A33', text: '#F2E9FF', sun: '#FF8F8F', sat: '#9BB8FF', accent: '#FF8A2A' } },
    { id: 'christmas', kind: '행사', name: '메리 크리스마스', story: '산타 모자와 선물 상자, 반짝이는 트리', motifs: ['gift', 'xtree', 'star'], accent: '#CF3A3A',
      day: { bg: '#FFF8F3', bg2: '#F4F9F2', panel: '#FFFCFA', text: '#3A2420' }, night: { bg: '#10221A', bg2: '#0D1C15', panel: '#162C22', text: '#F3EFE6', accent: '#F05A5A' } },
    { id: 'newyear', kind: '명절', name: '해피 뉴이어', story: '고깔모자 쓰고 새해 카운트다운!', motifs: ['firework', 'star', 'dot'], banner: 'newyear', accent: '#D99208',
      day: { bg: '#FFF9EB', bg2: '#F7F0FF', panel: '#FFFDF6', text: '#33283F' }, night: { bg: '#15132A', bg2: '#110F22', panel: '#1D1A36', text: '#F1ECFA', accent: '#F4C04A' } },
    { id: 'seollal', kind: '명절', name: '설날 · 근하신년', story: '복주머니와 매화, 근하신년 인사', motifs: ['lantern', 'petal', 'cloud'], banner: 'seollal', accent: '#C8372D',
      day: { bg: '#FFF6E9', bg2: '#FDEFE2', panel: '#FFFBF5', text: '#3B2418' }, night: { bg: '#21120F', bg2: '#1B0F0C', panel: '#2B1915', text: '#F8E9E0', accent: '#F0645A' } },
    { id: 'chuseok', kind: '명절', name: '추석 · 한가위', story: '보름달 아래 감·송편, 풍성한 한가위', motifs: ['persimmon', 'fullmoon', 'leaf'], banner: 'chuseok', accent: '#D9701A',
      day: { bg: '#FFF6E6', bg2: '#FBEFDD', panel: '#FFFBF4', text: '#3A2A18' }, night: { bg: '#141526', bg2: '#11121F', panel: '#1C1D33', text: '#F3EDE2', accent: '#F5B04A' } }
  ];
  const MODE_NAME = { day: '라이트', night: '다크' };
  // 시즌 혼합 컬렉션: 12지신이 섞여서 랜덤으로 나와요 (라이트·다크)
  for (const z of SEASONS) {
    for (const mode of ['day', 'night']) {
      const p = z[mode];
      THEMES.push({ id: 'season-' + z.id + (mode === 'night' ? '-night' : ''), group: 'season', season: z.id, kind: z.kind, mode, banner: z.banner || null,
        name: z.name + (mode === 'night' ? ' · 다크' : ''), concept: z.name, desc: `시즌 혼합 · ${MODE_NAME[mode]}`, story: z.story, accent: p.accent || z.accent, motifs: z.motifs, ...build(p) });
    }
  }
  for (const mode of ['day', 'night']) {
    THEMES.push({ ...THEMES.find((t) => t.id === 'season-spring' + (mode === 'night' ? '-night' : '')), id: 'season-auto' + (mode === 'night' ? '-night' : ''), kind: '자동', mode,
      name: '계절 따라 자동' + (mode === 'night' ? ' · 다크' : ''), concept: '계절 따라 자동', desc: `시즌 혼합 · ${MODE_NAME[mode]}`,
      story: '날짜에 맞춰 봄·여름·가을·겨울·할로윈·크리스마스·새해·설날·추석으로 저절로 바뀌어요', auto: true });
  }
  // 12지신 동물별 컨셉: 기본 컨셉 + 계절 따라 자동 + 시즌 옷 6가지, 컨셉마다 라이트·다크
  const OUTFITS = ['spring', 'summer', 'autumn', 'winter', 'halloween', 'christmas'];
  const OUTFIT_STORY = { spring: '벚꽃 아래 도시락 소풍', summer: '선글라스 끼고 바다로!', autumn: '베레모 쓰고 단풍길 산책', winter: '목도리 두르고 코코아 한 잔', halloween: '마녀 모자 쓰고 트릭 오어 트릿!', christmas: '산타 모자와 선물 상자' };
  const OUTFIT_NAME = { spring: '봄 소풍', summer: '여름 바캉스', autumn: '가을 나들이', winter: '겨울 눈꽃', halloween: '할로윈', christmas: '크리스마스' };
  const CONCEPTS = ['base', 'auto', ...OUTFITS];
  for (const c of LINA) {
    for (const o of OUTFITS) {
      const z = SEASONS.find((x) => x.id === o);
      for (const mode of ['day', 'night']) {
        const sp = z[mode], cp = c[mode];
        const p = { ...sp, bg: mix(sp.bg, cp.bg, 0.35), bg2: sp.bg2 && mix(sp.bg2, cp.bg2 || cp.bg, 0.35), panel: mix(sp.panel, cp.panel, 0.35) };
        THEMES.push({ id: `lina-${c.char}-${o}-${mode}`, group: 'linaverse', char: c.char, mode, ck: o, outfit: o,
          name: `${OUTFIT_NAME[o]}` + (mode === 'night' ? ' · 다크' : ''), concept: OUTFIT_NAME[o], story: OUTFIT_STORY[o],
          desc: `${CHAR_NAME[c.char]} · ${MODE_NAME[mode]}`, accent: sp.accent || z.accent, motifs: z.motifs, ...build(p) });
      }
    }
    for (const mode of ['day', 'night']) {
      THEMES.push({ ...THEMES.find((t) => t.id === `lina-${c.char}-autumn-${mode}`), id: `lina-${c.char}-auto-${mode}`, ck: 'auto', outfit: null, auto: true,
        name: '계절 옷 자동' + (mode === 'night' ? ' · 다크' : ''), concept: '계절 옷 자동', story: `날짜에 맞춰 ${CHAR_NAME[c.char]}가 계절 옷으로 갈아입어요`, desc: `${CHAR_NAME[c.char]} · ${MODE_NAME[mode]}` });
    }
  }

  // 날짜 → 계절·명절 (설날·추석은 음력으로 계산)
  function L() { return (typeof window !== 'undefined' && window.Lunar) || (typeof require === 'function' ? require('./lunar.js') : null); }
  function seasonKey(date) {
    const d = date || new Date(), y = d.getFullYear(), m = d.getMonth() + 1, day = d.getDate();
    const near = (s, k) => { if (!s) return false; const t = new Date(s + 'T00:00:00'); return Math.abs((new Date(y, m - 1, day) - t) / 864e5) <= k; };
    const lu = L();
    if (m === 1 && day <= 3) return 'newyear';
    if (lu && (near(lu.seollal(y), 2))) return 'seollal';
    if (lu && (near(lu.chuseok(y), 2))) return 'chuseok';
    if (m === 10 && day >= 20) return 'halloween';
    if (m === 12 && day <= 25) return 'christmas';
    if (m === 12) return 'winter';
    if (m >= 3 && m <= 5) return 'spring';
    if (m >= 6 && m <= 8) return 'summer';
    if (m >= 9 && m <= 11) return 'autumn';
    return 'winter';
  }
  // 그림이 있는 계절 (설날·새해는 겨울 옷, 추석은 가을 옷)
  const outfitOf = (k) => ({ newyear: 'winter', seollal: 'winter', chuseok: 'autumn' }[k] || k);
  const bannerOf = (k) => (['newyear', 'seollal', 'chuseok'].includes(k) ? k : null);

  const byId = new Map(THEMES.map((t) => [t.id, t]));
  // 기본(무료) 먼저, 캐릭터·시즌 컬렉션은 프리미엄(지금은 미리 체험 중)
  const GROUPS = [['light', '기본 라이트'], ['dark', '기본 다크'], ['linaverse', '12지신 캐릭터'], ['season', '시즌 혼합 컬렉션']];
  const PREMIUM_GROUPS = ['linaverse', 'season'];
  const FREE_SHAPES = ['square', 'soft'];
  const PREMIUM_SHAPES = ['shade', 'block', 'tile', 'notebook', 'stamp', 'cozy', 'puffy', 'bubble', 'glass', 'candy'];
  const isPremium = (id) => { const t = byId.get(id); return !!(t && PREMIUM_GROUPS.includes(t.group)); };
  // 이용 권한: 지금은 모든 프리미엄을 무료로 미리 체험 ('preview'). 나중에 결제 연동 시 여기만 바꾸면 됨
  const PLAN = 'preview';
  const canUse = (_id) => PLAN === 'preview' || PLAN === 'premium';
  THEMES.forEach((t) => { t.premium = PREMIUM_GROUPS.includes(t.group); });
  // 지금 실제로 쓸 테마 (자동이면 날짜에 맞는 시즌 테마)
  function actual(id, date) {
    const t = byId.get(id);
    if (t && t.auto) {
      const k = seasonKey(date), n = t.mode === 'night';
      if (t.char) return byId.get(`lina-${t.char}-${outfitOf(k)}-${t.mode}`) || t;
      return byId.get('season-' + k + (n ? '-night' : '')) || t;
    }
    return t || null;
  }

  // ---------------------------------------------------------------- 글자 크기 (달력 스타일)
  const TYPO_PRESETS = {
    bigdate: { name: '큰 날짜 · 얇게', desc: '날짜 숫자는 크고 가늘게, 일정은 작고 단정하게', date: 1.55, dateWeight: 300, chip: 0.8, list: 0.95, clock: 3.6, icon: 1, weekday: 0.82, title: 1.7 },
    balanced: { name: '균형', desc: '처음 쓰기 무난한 기본 크기', date: 1.1, dateWeight: 500, chip: 0.82, list: 0.98, clock: 3.0, icon: 1, weekday: 0.82, title: 1.6 },
    clear: { name: '또렷하게', desc: '날짜·일정 모두 굵고 크게', date: 1.4, dateWeight: 700, chip: 0.95, list: 1.1, clock: 3.2, icon: 1.15, weekday: 0.95, title: 1.9 },
    minimal: { name: '미니멀', desc: '작고 가볍게, 정보를 많이', date: 0.95, dateWeight: 400, chip: 0.76, list: 0.9, clock: 2.6, icon: 0.9, weekday: 0.76, title: 1.4 },
    large: { name: '크게 보기', desc: '멀리서도 잘 보이게 전체를 크게', date: 1.7, dateWeight: 500, chip: 1.0, list: 1.15, clock: 4.2, icon: 1.25, weekday: 1.0, title: 2.1 }
  };
  const TYPO_KEYS = ['date', 'dateWeight', 'chip', 'list', 'clock', 'icon', 'weekday', 'title'];
  function typo(a) {
    const t = (a && a.typo) || {};
    const base = TYPO_PRESETS[t.preset] || TYPO_PRESETS.bigdate;
    const out = { ...base };
    if (t.preset === 'custom') TYPO_KEYS.forEach((k) => { if (t[k] != null && !isNaN(t[k])) out[k] = Number(t[k]); });
    return out;
  }

  // 설정값(테마 + 직접 고른 색) → 실제로 쓸 색
  function resolve(a) {
    a = a || {};
    const t = actual(a.theme) || byId.get('midnight');
    const vars = { ...t.vars };
    let dark = t.dark;
    const bgC = isHex(a.bgColor) ? '#' + String(a.bgColor).replace('#', '') : null;
    const txC = isHex(a.textColor) ? '#' + String(a.textColor).replace('#', '') : null;
    if (bgC || txC) {
      const bg = bgC || vars['--bg-solid'];
      const text = txC || (bgC ? (lum(bgC) < 0.45 ? '#ECEAE6' : '#24211C') : vars['--text']);
      const b = build({ bg, text, panel: bgC ? undefined : vars['--panel-solid'], pop: bgC ? undefined : vars['--popover'], sun: bgC ? undefined : vars['--sun'], sat: bgC ? undefined : vars['--sat'] });
      Object.assign(vars, b.vars);
      if (!bgC) vars['--bg'] = t.vars['--bg'];
      dark = b.dark;
    }
    return { theme: t, vars, dark };
  }
  // 장식 바탕 무늬 (그림을 흩뿌린 타일)
  function patternFor(t, opacity) {
    if (!t || !t.motifs) return '';
    const m = t.motifs.map((k) => MOTIF[k]).filter(Boolean);
    const inner = (svg, x, y, s, r) => svg.replace('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">', `<g transform="translate(${x} ${y}) rotate(${r} ${s / 2} ${s / 2}) scale(${s / 24})">`).replace('</svg>', '</g>');
    const tile = `<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180"><g opacity="${opacity || 0.08}">${inner(m[0], 18, 20, 26, -12)}${inner(m[1] || m[0], 110, 40, 22, 14)}${inner(m[2] || m[0], 58, 108, 24, 8)}${inner(m[0], 140, 128, 18, -20)}</g></svg>`;
    return svgUrl(tile);
  }

  const api = { PREMIUM_GROUPS, FREE_SHAPES, PREMIUM_SHAPES, PLAN, isPremium, canUse, THEMES, GROUPS, LINA, SEASONS, CONCEPTS, OUTFITS, OUTFIT_NAME, CHAR_NAME, MOTIF, byId: (id) => byId.get(id) || null, actual, resolve, patternFor, svgUrl, mix, lum, seasonKey, outfitOf, bannerOf, TYPO_PRESETS, TYPO_KEYS, typo };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') root.DeskThemes = api;
})(typeof window !== 'undefined' ? window : globalThis);
