// DeskCal 캘린더 화면
const API = window.deskcal;
const WD = ["일","월","화","수","목","금","토"];
let S = {events:[],sources:[],errors:[],updated:null,view:"month",mode:"wallpaper",editing:false,iconGutter:170,panels:{},appearance:{}};
let cursor = new Date();
let DEMO = false;
const A = () => S.appearance || {};
const CH = () => S.characters || {};
const chOn = k => !!(window.Chars && CH().enabled && CH()[k]);
// ---- 시간대: 달력은 '앱 시간대'의 벽시계 시각으로 계산 ----
const appTZ = () => TZ.resolve(A().timeZone);
function NOW(){ return TZ.wall(new Date(), appTZ()); }
const W = d => TZ.wall(d, appTZ());
function altTimes(e, useEnd){
  if (e.allDay || !e.abs) return [];
  const app = appTZ(), base = useEnd ? e.absEnd : e.abs, primary = useEnd ? e.e2 : e.s;
  const list = (A().worldZones||[]).filter(z=>TZ.valid(z) && z!==app);
  const zones = e.tz && TZ.valid(e.tz) && e.tz!==app && !list.includes(e.tz) ? [e.tz, ...list] : list;
  return zones.map(z=>{
    const w = TZ.wall(base, z);
    const dd = Math.round((startOfDay(w) - startOfDay(primary))/864e5);
    return { zone:z, saved: z===e.tz, text:`${TZ.label(z)} ${tm(w)}${dd>0?" (다음날)":dd<0?" (전날)":""}` };
  });
}
function altText(e){ return altTimes(e).map(a=>a.saved ? a.text+" 기준" : a.text).join(" · "); }

const pad = n => String(n).padStart(2,"0");
const ymd = d => `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const sameDay = (a,b) => ymd(a)===ymd(b);
const esc = s => String(s??"").replace(/[&<>"]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]));
const $ = id => document.getElementById(id);
const startOfDay = d => new Date(d.getFullYear(),d.getMonth(),d.getDate());
const addDays = (d,n) => new Date(d.getFullYear(),d.getMonth(),d.getDate()+n);
function tm(d){
  if (A().timeFormat === "12"){ const h=d.getHours(); return `${h<12?"오전":"오후"} ${h%12||12}:${pad(d.getMinutes())}`; }
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function tmShort(d){
  if (A().timeFormat === "12"){ const h=d.getHours(); return `${h<12?"오전":"오후"} ${h%12||12}${d.getMinutes()?":"+pad(d.getMinutes()):"시"}`; }
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
const weekStart = () => Number(A().weekStart)||0;
const orderWD = () => Array.from({length:7},(_,i)=>(i+weekStart())%7);

function parse(e){
  if (e.allDay){
    const s = new Date(e.start+"T00:00:00");
    let en = new Date(e.end+"T00:00:00");
    if (isNaN(en) || en<=s) en = new Date(s.getTime()+864e5);
    return {...e, s, e2:en};
  }
  const abs = new Date(e.start);
  let absEnd = new Date(e.end);
  if (isNaN(absEnd) || absEnd<=abs) absEnd = new Date(abs.getTime()+36e5);
  return {...e, abs, absEnd, s:W(abs), e2:W(absEnd)};
}
let parsed = [], holidays = new Map();
function eventsOn(day){
  const d0 = startOfDay(day), d1 = addDays(d0,1);
  return parsed.filter(x => !x.holiday && x.s < d1 && x.e2 > d0).sort((a,b)=> (b.allDay-a.allDay) || (a.s-b.s));
}
const holidayOn = day => holidays.get(ymd(day)) || "";

// ---------------- 시계·다음 일정 ----------------
let nextId = null;
function renderClock(){
  const n = NOW();
  if (A().timeFormat === "12"){ const h=n.getHours(); $("clock").innerHTML = `${h%12||12}:${pad(n.getMinutes())}<small>${h<12?"오전":"오후"}</small>`; }
  else $("clock").textContent = `${pad(n.getHours())}:${pad(n.getMinutes())}`;
  const hol = holidayOn(n);

  $("date").innerHTML = `${n.getFullYear()}년 <b>${n.getMonth()+1}월 ${n.getDate()}일 ${WD[n.getDay()]}요일</b>${hol?` · <span style="color:var(--sun)">${esc(hol)}</span>`:""}`;

  const zones = (A().worldZones||[]).filter(z=>TZ.valid(z) && z!==appTZ());
  const real = new Date();
  $("wclock").innerHTML = zones.length ? `<span class="wz home"><b>${esc(TZ.label(appTZ()))}</b> 기준</span>` + zones.map(z=>{
    const w = TZ.wall(real, z), dd = Math.round((startOfDay(w)-startOfDay(n))/864e5);
    return `<span class="wz"><span class="wn">${esc(TZ.label(z))}</span><b>${tm(w)}</b><span class="wd2">${dd>0?"다음날 · ":dd<0?"전날 · ":""}${TZ.diffLabel(real, appTZ(), z)}</span></span>`;
  }).join("") : "";
  $("wclock").classList.toggle("hide", !zones.length);
  renderNext();
}
// ---------------- 캐릭터 친구 ----------------
// Linaverse 테마면 그 테마의 동물, 아니면 설정에서 고른 동물(기본 토끼)
function buddyId(){
  const t = window.DeskThemes && DeskThemes.actual(A().theme, NOW());
  if (t && t.char) return t.char;
  const b = CH().buddy;
  return b && b !== "theme" && Chars.byId(b) ? b : "rabbit";
}
function setBuddy(img, c){
  if (!img) return;
  if (!c){ img.classList.add("hide"); img.removeAttribute("data-c"); return; }
  img.classList.remove("hide");
  if (img.dataset.c === c.id) return;
  img.dataset.c = c.id; img.src = Chars.img(c.id);
  const tip = `${c.name} 친구 · 눌러 보세요`;
  img.title = tip; img.setAttribute("aria-label", tip); img.setAttribute("role","button");
}
const CHAR_LINES = {
  rat: ["책갈피처럼 오늘 할 일을 콕콕 표시해 둘게요!", "치즈 한 조각 먹고 힘내요 🧀"],
  ox: ["천천히 가도 괜찮아요, 꾸준함이 최고예요!", "우유 한 잔 마시고 시작해요 🥛"],
  tiger: ["어흥! 오늘도 씩씩하게 가 봐요!", "귤처럼 상큼한 하루 되세요 🍊"],
  rabbit: ["깡총! 오늘도 가볍게 뛰어 봐요!", "벚꽃처럼 활짝 웃는 하루 되세요 🌸"],
  dragon: ["구름 위에서 응원하고 있어요! ☁️", "오늘 하루도 반짝반짝 빛나요 ✨"],
  snake: ["잠깐 차 한 잔의 여유, 어때요? 🍵", "차분하게, 하나씩 해결해 봐요"],
  horse: ["별빛처럼 달려가 봐요! ⭐", "회전목마처럼 신나는 하루 되세요"],
  goat: ["솜사탕처럼 폭신한 하루 되세요 ☁️", "피곤하면 잠깐 눈 감고 쉬어요 🌙"],
  monkey: ["바나나 하나 먹고 기운 내요! 🍌", "오늘은 장난처럼 즐겁게 해치워요!"],
  rooster: ["꼬끼오! 좋은 일이 생길 거예요 ☀️", "갓 구운 빵처럼 따뜻한 하루 되세요 🍞"],
  dog: ["멍! 산책하듯 가볍게 가 봐요 🐾", "언제나 곁에서 응원하고 있어요!"],
  pig: ["달콤한 디저트처럼 기분 좋은 하루! 🍓", "맛있는 거 먹고 힘내요 🍩"]
};
const GENERAL_LINES = ["오늘도 잘하고 있어요!", "충분히 잘하고 있어요. 진짜로요 :)", "숨 한 번 크게 쉬고 가요", "작은 일부터 하나씩!", "물 한 잔 마셨어요? 💧",
  "어깨 한 번 쭉 펴 볼까요?", "오늘 하루도 고마워요", "실수해도 괜찮아요, 다시 하면 돼요", "벌써 이만큼 했어요!", "웃으면 일도 술술 풀려요 😊",
  "잠깐 창밖 한 번 보고 와요", "당신 편이에요, 늘!", "오늘의 나에게 박수 👏", "좋은 소식이 올 것 같은 날이에요"];
function cheerLine(id){
  const n = NOW(), h = n.getHours(), day = n.getDay();
  const today = eventsOn(n), left = today.filter(e=>!e.allDay && e.s > n);
  const ctxLines = [];
  if (h < 11) ctxLines.push("좋은 아침이에요! 오늘도 같이 힘내요 ☀️");
  else if (h < 14) ctxLines.push("점심은 맛있게 드셨어요? 🍚");
  else if (h < 18) ctxLines.push("오후도 조금만 더 힘내요!");
  else if (h < 22) ctxLines.push("오늘도 정말 수고 많으셨어요 🌙");
  else ctxLines.push("늦었어요, 이제 푹 쉬어요 💤");
  if (today.length) ctxLines.push(`오늘 일정 ${today.length}개! 차근차근 해 봐요`); else ctxLines.push("오늘은 일정이 없어요. 여유를 즐겨요 🍀");
  if (left[0]){ const m = Math.max(1, Math.round((left[0].s - n)/6e4)); if (m <= 90) ctxLines.push(`곧 '${left[0].title}' 일정이에요 (${m}분 후)`); }
  if (day === 5) ctxLines.push("금요일이에요! 조금만 더 힘내요 🎉");
  if (day === 0 || day === 6) ctxLines.push("주말이에요, 푹 쉬는 것도 일이에요!");
  if (day === 1 && h < 13) ctxLines.push("월요일 시작! 천천히 시동 걸어요 🚗");
  // 4번 중 1번은 지금 상황에 맞는 말, 나머지는 영어 한 줄·명언·응원·감성·꿀팁·알쓸신잡을 차례로
  const tally = (window.__lineTally = (window.__lineTally||0) + 1);
  const L = tally % 4 === 1 ? null : (window.DeskLines && DeskLines.next((CH().lines)||null));
  if (!L){
    const pool = Math.random() < 0.6 ? ctxLines : (CHAR_LINES[id] || GENERAL_LINES);
    return { text: pool[Math.floor(Math.random()*pool.length)] };
  }
  return L;
}
// 저절로 말 걸기: 설정한 간격마다 응원 친구가 먼저 말해요
let autoTalkT = null, autoTalkKey = "";
function setupAutoTalk(){
  const c = CH(), key = `${c.autoTalk}|${c.autoTalkMin}`;
  if (key === autoTalkKey) return;
  autoTalkKey = key; clearInterval(autoTalkT); autoTalkT = null;
  if (!c.autoTalk) return;
  const min = Math.max(1, Number(c.autoTalkMin) || 30);
  autoTalkT = setInterval(()=>{
    const bd = $("buddy");
    if (!bd || bd.classList.contains("hide") || document.hidden || document.querySelector(".bubble")) return;
    petReact(bd);
  }, min * 60000);
}
function motifsFor(id){
  const t = window.DeskThemes && DeskThemes.actual(A().theme, NOW());
  if (t && t.motifs && (t.char === id || t.season)) return t.motifs;
  const L = window.DeskThemes && DeskThemes.LINA.find(x=>x.char===id);
  return L ? L.motifs : ["star","heart","sparkle"];
}
let bubbleT = null;
function petReact(img){
  if (!img || img.classList.contains("hide")) return;
  const id = img.dataset.c || buddyId();
  if (img.id === "buddy") maybeReshuffle();
  const anims = ["a-jump","a-spin","a-wiggle","a-squish"];
  anims.forEach(a=>img.classList.remove(a)); void img.offsetWidth;
  img.classList.add(anims[Math.floor(Math.random()*anims.length)]);
  const r = img.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
  // 컨셉 그림 발사!
  const ms = motifsFor(id);
  for (let i=0;i<10;i++){
    const sp = document.createElement("div"); sp.className = "spark";
    const ang = Math.random()*Math.PI*2, dist = 70 + Math.random()*90;
    sp.style.left = (cx-13)+"px"; sp.style.top = (cy-13)+"px";
    sp.style.setProperty("--dx", Math.cos(ang)*dist+"px"); sp.style.setProperty("--dy", (Math.sin(ang)*dist - 30)+"px");
    sp.style.setProperty("--s", (0.8+Math.random()*0.7).toFixed(2)); sp.style.setProperty("--r", (Math.random()*540-270).toFixed(0)+"deg");
    sp.style.animationDelay = (Math.random()*0.12).toFixed(2)+"s";
    sp.innerHTML = DeskThemes.MOTIF[ms[i % ms.length]] || "";
    document.body.appendChild(sp); setTimeout(()=>sp.remove(), 1300);
  }
  // 말풍선
  document.querySelectorAll(".bubble").forEach(b=>b.remove());
  const b = document.createElement("div"); b.className = "bubble"; b.setAttribute("role","status");
  const ln = cheerLine(id);
  if (typeof ln === "string") b.textContent = ln;
  else {
    b.innerHTML = `<span class="bt">${esc(ln.text)}</span>` + (ln.sub ? `<span class="bs">${esc(ln.sub)}</span>` : "") + (ln.by ? `<span class="bb">— ${esc(ln.by)}</span>` : "");
    if (ln.kind) b.dataset.kind = ln.kind;
  }
  document.body.appendChild(b);
  const rightSide = r.left > innerWidth/2;
  let x = rightSide ? r.right - b.offsetWidth + 6 : r.left - 6;
  x = Math.max(8, Math.min(x, innerWidth - b.offsetWidth - 8));
  let y = r.bottom + 12;
  if (y + b.offsetHeight > innerHeight - 8){ y = r.top - b.offsetHeight - 12; b.classList.add("up"); }
  if (rightSide) b.classList.add("r");
  b.style.left = x+"px"; b.style.top = y+"px";
  // 말풍선 보이는 시간: 설정값(초) 또는 자동(글 길이에 맞춰 3~9초)
  const sec = Number(CH().bubbleSec) || 0;
  const dur = sec > 0 ? sec * 1000 : Math.min(9000, 3200 + (b.textContent.length * 55));
  clearTimeout(bubbleT); bubbleT = setTimeout(()=>{ b.classList.add("out"); setTimeout(()=>b.remove(), 320); }, dur);
}
document.addEventListener("click", ev=>{ const bd = ev.target.closest("#buddy"); if (bd){ ev.stopPropagation(); petReact(bd); } }, true);
// 생일: 태어난 해(양력)로 나이·띠
function birthInfo(e){
  if (!e.birthYear || !chOn("birthday")) return "";
  const z = Chars.ofYear(e.birthYear), age = e.s.getFullYear() - e.birthYear;
  const tip = `${e.birthYear}년생 · ${z.name}띠 (양력 연도 기준이라 1~2월생은 설 전이면 전년도 띠일 수 있어요)`;
  return `<span class="bd" title="${esc(tip)}"><img class="chr" src="${Chars.img(z.id)}" alt="">${age>0?`${age}번째 생일 · `:""}${z.name}띠</span>`;
}
function renderNext(){
  const n = NOW();
  const list = parsed.filter(e=>!e.allDay && !e.holiday && e.e2>n).sort((a,b)=>a.s-b.s);
  const box = $("next");
  if(!list.length){ nextId=null; box.style.removeProperty("--c"); box.innerHTML=`<div class="lbl">다음 일정</div><div class="t">예정된 일정이 없어요</div><div class="c">여유로운 하루 되세요</div>`; return; }
  const e = list[0]; nextId = e.id;
  let c;
  if (e.s<=n) c = `진행 중 · ${tm(e.e2)} 종료`;
  else {
    const m = Math.max(1, Math.ceil((e.s-n)/6e4));
    const when = sameDay(e.s,n) ? "" : sameDay(e.s,addDays(n,1)) ? "내일 " : `${e.s.getMonth()+1}/${e.s.getDate()}(${WD[e.s.getDay()]}) `;
    c = m<60 ? `${m}분 후 시작` : m<1440 ? `${when}${tm(e.s)} · ${Math.floor(m/60)}시간 ${m%60}분 후` : `${when}${tm(e.s)}`;
  }
  box.style.setProperty("--c", e.color);
  const alt = altText(e);
  box.innerHTML = `<div class="lbl">다음 일정</div><div class="t">${esc(e.title)}</div><div class="c">${c}</div>${alt?`<div class="alt">${esc(alt)}</div>`:""}`;
  box.setAttribute("aria-label", `다음 일정: ${e.title}, ${c}`);
}

// ---------------- 오늘·내일 ----------------
function evRow(e, day){
  const n = NOW();
  const past = !e.allDay && e.e2<=n, now = !e.allDay && e.s<=n && e.e2>n;
  const t = e.allDay ? "종일" : (e.s < startOfDay(day) ? "계속" : tm(e.s));
  const alt = altText(e);
  const rem = Array.isArray(e.remind) ? (e.remind.length ? `알림 ${e.remind.length}개` : "알림 없음") : "";
  const RP = {daily:"매일", weekly:"매주", monthly:"매달", yearly:"매년"};
  const sub = (e.lunar && e.lunar.m ? `<span title="음력 일정">음력 ${e.lunar.leap?"윤":""}${e.lunar.m}.${e.lunar.d}</span>` : "") + (e.recurring?`<span title="반복 일정">↻ ${RP[e.repeat]||"반복"}</span>`:"") + birthInfo(e) + (e.category?`<span class="cat" style="--c:${e.color}">${esc(e.category)}</span>`:"") + (e.location?`<span>${esc(e.location)}</span>`:"") + (alt?`<span class="alt">${esc(alt)}</span>`:"") + (rem?`<span>${rem}</span>`:"");
  return `<button class="ev ${past?"past":""} ${now?"now":""}" data-id="${esc(e.id)}"${dragAttr(e)} style="--c:${e.color}" aria-label="${esc(t+" "+e.title)}"><span class="bar"></span><span class="tm">${t}</span><span><div class="tt">${esc(e.title)}</div>${sub?`<div class="lc">${sub}</div>`:""}</span></button>`;
}
function withNowLine(list, day, render){
  if (!sameDay(day, NOW())) return list.map(render).join("");
  const n = NOW(); let out = "", placed = false;
  list.forEach(e=>{ if(!placed && !e.allDay && e.s > n){ out += `<div class="nowline">지금 ${tm(n)}</div>`; placed = true; } out += render(e); });
  if (!placed && list.some(e=>!e.allDay)) out += `<div class="nowline">지금 ${tm(n)}</div>`;
  return out;
}
function dayBlock(label, day){
  const list = eventsOn(day);
  const rows = list.length ? withNowLine(list, day, e=>evRow(e, day)) : `<div class="empty">${sameDay(day,NOW())?"오늘은 일정이 없어요":"일정 없음"}</div>`;
  return `<div><div class="ptitle"><span>${label}</span><span>${list.length}건</span></div><div class="day-list">${rows}</div></div>`;
}
function memoBlock(){
  const notes = S.notes||[];
  const open = notes.filter(n=>!n.done).length;
  const rows = notes.length ? notes.slice(0,30).map(n=>{
    const lines = String(n.text||"").split("\n").map(l=>l.trim()).filter(Boolean);
    const title = lines[0]||"(빈 메모)", more = lines.slice(1).join(" · ");
    return `<div class="memo ${n.done?"done":""}" style="--c:${n.color}">
      <button class="mchk" data-toggle="${esc(n.id)}" role="checkbox" aria-checked="${!!n.done}" aria-label="${esc(title)} 완료 표시"></button>
      <button class="mtxt" data-note="${esc(n.id)}"><span class="mrow"><span class="mt">${esc(title)}</span>${n.done && n.sticker && chOn("stickers") ? `<img class="chr mstk" src="${Chars.img(n.sticker)}" alt="${esc(Chars.byId(n.sticker)?.name||"")} 스티커">` : ""}</span>${more?`<span class="mm">${esc(more)}</span>`:""}${n.category?`<span class="cat" style="--c:${n.color}">${esc(n.category)}</span>`:""}</button></div>`;
  }).join("") : `<div class="empty">날짜 없는 메모가 여기에 모여요</div>`;
  return `<div><div class="ptitle"><span>메모</span><span>${open}건 <button class="addmemo" data-addmemo aria-label="새 메모">+ 메모</button></span></div><div class="day-list">${rows}</div></div>`;
}
function renderAgenda(){
  const t = NOW(), tm1 = addDays(t,1), P = S.panels||{};
  const hol = holidayOn(tm1);
  $("agenda").innerHTML = (P.today!==false ? dayBlock("오늘", t) : "") + (P.tomorrow!==false ? dayBlock(`내일 · ${tm1.getMonth()+1}/${tm1.getDate()} ${WD[tm1.getDay()]}${hol?" · "+esc(hol):""}`, tm1) : "") + (P.memo!==false ? memoBlock() : "");
}

// ---------------- 달력 ----------------
let chipTime = true;
const canMove = e => !!(e.writable && !e.recurring && !e.holiday);
const dragAttr = e => canMove(e) ? ` draggable="true"` : "";
function chip(e){
  const label = `${e.allDay?"종일":tm(e.s)} ${e.title}${e.location?" · "+e.location:""}`; // 마우스 설명엔 시간대 안 넣음
  return e.allDay
    ? `<button class="chip allday" data-id="${esc(e.id)}"${dragAttr(e)} style="--c:${e.color}" title="${esc(label)}">${esc(e.title)}</button>`
    : `<button class="chip timed" data-id="${esc(e.id)}"${dragAttr(e)} style="--c:${e.color}" title="${esc(label)}">${chipTime?`<span class="ct">${tmShort(e.s)}</span>`:""}${e.recurring?"↻ ":""}${esc(e.title)}</button>`;
}
function weekStartOf(d){ const off = (d.getDay()-weekStart()+7)%7; return addDays(startOfDay(d), -off); }
function isAway(){
  const t = NOW();
  if (S.view==="week") return !sameDay(weekStartOf(t), weekStartOf(cursor));
  return t.getFullYear()!==cursor.getFullYear() || t.getMonth()!==cursor.getMonth();
}
function renderTitle(){
  let m, y;
  if (S.view==="week"){
    const s = weekStartOf(cursor), e = addDays(s,6);
    m = `${s.getMonth()+1}월 ${s.getDate()}일 – ${e.getMonth()!==s.getMonth()?(e.getMonth()+1)+"월 ":""}${e.getDate()}일`; y = s.getFullYear();
  } else { m = `${cursor.getMonth()+1}월`; y = cursor.getFullYear(); }
  $("title").innerHTML = `<span class="y">${y}년</span><span class="m">${m}</span><span class="caret">▾</span>`;
  // 화살표 옆에 이전·다음 달 이름
  if (S.view==="week"){ $("prevL").textContent = "이전 주"; $("nextL").textContent = "다음 주"; }
  else { const pm = (cursor.getMonth()+11)%12+1, nm = (cursor.getMonth()+1)%12+1; $("prevL").textContent = pm+"월"; $("nextL").textContent = nm+"월"; }
  $("prev").setAttribute("aria-label", S.view==="week" ? "이전 주 (←)" : "이전 달 (←)"); $("prev").dataset.tip = $("prev").getAttribute("aria-label");
  $("nextBtn").setAttribute("aria-label", S.view==="week" ? "다음 주 (→)" : "다음 달 (→)"); $("nextBtn").dataset.tip = $("nextBtn").getAttribute("aria-label");
  const away = isAway();
  $("todayBtn").classList.toggle("away", away);
  $("todayBtn").textContent = away ? "← 오늘로" : "오늘";
}
function renderMonth(){
  const t = NOW(), today0 = startOfDay(t); const y=cursor.getFullYear(), m=cursor.getMonth();
  const first = new Date(y,m,1);
  const lead = (first.getDay()-weekStart()+7)%7;
  const start = addDays(first, -lead);
  const weeks = Math.ceil((lead+new Date(y,m+1,0).getDate())/7);
  const mainH = $("main").clientHeight, mainW = $("main").clientWidth;
  const rem = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
  const TY = window.DeskThemes ? DeskThemes.typo(A()) : {date:1.2, chip:.8, title:1.6, weekday:.8};
  const cellH = (mainH - (TY.title*1.35 + 1.1 + TY.weekday*1.45 + .5)*rem) / weeks;
  const MAX = Math.max(1, Math.floor((cellH - (TY.date*1.7 + .55)*rem) / (TY.chip*1.42*rem + 2)));
  chipTime = mainW / 7 > 8*rem;
  const compact = mainW < 26*rem || cellH < 3.6*rem;
  const away = isAway();
  let html = `<div class="wkhead" role="row">${orderWD().map(i=>`<div class="wk ${i===0?"sun":i===6?"sat":""} ${i===t.getDay() && !away?"todaycol":""}" role="columnheader">${WD[i]}</div>`).join("")}</div><div class="grid" role="grid" aria-label="${y}년 ${m+1}월">`, count=0;
  for(let i=0;i<weeks*7;i++){
    const d = addDays(start,i);
    const list = eventsOn(d); if(d.getMonth()===m) count+=list.length;
    const hol = holidayOn(d), isToday = sameDay(d,t);
    const cls = ["cell", d.getMonth()!==m?"other":"", isToday?"today":"", d<today0 && A().dimPast!==false?"past":"", d.getDay()===0?"sun":d.getDay()===6?"sat":"", hol?"holiday":""].join(" ");
    let inner;
    if (compact) {
      inner = list.length ? `<div class="dots">${list.slice(0,4).map(e=>`<i style="background:${e.color}"></i>`).join("")}${list.length>4?`<span>+${list.length-4}</span>`:""}</div>` : "";
    } else {
      // 칸에 들어가는 만큼 글자로 보여 주고, 넘치는 건 날짜 옆 '+N'
      inner = list.slice(0,MAX).map(chip).join("");
    }
    const moreN = compact ? 0 : list.length - Math.min(list.length, MAX);
    const aria = `${d.getMonth()+1}월 ${d.getDate()}일 ${WD[d.getDay()]}요일${isToday?", 오늘":""}${hol?", "+hol:""}, 일정 ${list.length}건`;
    html += `<div class="${cls}" role="gridcell" data-date="${ymd(d)}" tabindex="${isToday?0:-1}" aria-label="${esc(aria)}" ${isToday?'aria-current="date"':""}><div class="dn"><span class="n" data-day="${ymd(d)}">${d.getDate()}</span>${isToday?`<span class="todaytag">오늘</span>`:""}${hol?`<span class="hol">${esc(hol)}</span>`:""}${lunarTag(d, list)}${stickerFor(d)}${moreN?`<button class="more" data-day="${ymd(d)}" aria-label="일정 ${moreN}건 더 보기">+${moreN}</button>`:""}</div>${inner}</div>`;
  }
  $("body").innerHTML = html + "</div>";
  if (away){ const f = document.querySelector(`.cell[data-date="${ymd(first)}"]`); if (f) f.tabIndex = 0; }
  $("count").textContent = `${count}건`;
}
// 음력으로 지정한 일정이 있는 날: 작게 음력 날짜
function lunarTag(d, list){
  if (!window.Lunar || !list.some(e=>e.lunar && e.lunar.m)) return "";
  return `<span class="lun" title="음력">음 ${Lunar.label(Lunar.toLunar(d))}</span>`;
}
function stickerFor(d){
  const got = chOn("stickers") && (S.stickerDays||{})[ymd(d)];
  if (!got || !got.length) return "";
  const names = got.map(id=>Chars.byId(id)?.name).filter(Boolean);
  return `<img class="chr stk" src="${Chars.img(got[got.length-1])}" alt="" title="${esc(`이날 받은 스티커: ${names.join(", ")}`)}">`;
}
function renderWeek(){
  const t = NOW(), n = NOW();
  const start = weekStartOf(cursor);
  let html = `<div class="week" role="grid">`, count=0;
  for(let i=0;i<7;i++){
    const d = addDays(start,i);
    const list = eventsOn(d); count += list.length;
    const hol = holidayOn(d), isToday = sameDay(d,t);
    const cls = ["wcol", isToday?"today":"", d.getDay()===0?"sun":d.getDay()===6?"sat":"", hol?"holiday":""].join(" ");
    const render = e=>`<button class="wev ${e.allDay?"allday":""} ${!e.allDay&&e.e2<=n?"past":""}" data-id="${esc(e.id)}" style="--c:${e.color}" title="${esc(e.title)}"><div class="t1">${e.allDay?"종일":tm(e.s)+" – "+tm(e.e2)}</div><div class="t2">${esc(e.title)}</div>${altText(e)?`<div class="t3">${esc(altText(e))}</div>`:""}</button>`;
    html += `<div class="${cls}" role="gridcell" data-date="${ymd(d)}" tabindex="${isToday?0:-1}" aria-label="${esc(`${d.getMonth()+1}월 ${d.getDate()}일 ${WD[d.getDay()]}요일${isToday?", 오늘":""}, 일정 ${list.length}건`)}" ${isToday?'aria-current="date"':""}><div class="wd">${WD[d.getDay()]} <span class="n" data-day="${ymd(d)}">${d.getDate()}</span>${hol?`<span class="hol">${esc(hol)}</span>`:""}</div>${withNowLine(list,d,render)}</div>`;
  }
  $("body").innerHTML = html + "</div>";
  $("count").textContent = `${count}건`;
}
function renderMain(){ renderTitle(); (S.view==="week" ? renderWeek : renderMonth)(); }

// ---------------- 바닥 ----------------
function renderFooter(){
  const items = S.colorBy==="category" && (S.categories||[]).length ? S.categories : (S.sources||[]).filter(s=>!s.holiday);
  $("legend").innerHTML = items.map(s=>`<span style="--c:${s.color}">${esc(s.name)}</span>`).join("");
  const up = S.updated ? tm(W(new Date(S.updated))) : "-";
  const err = (S.errors||[]).length ? ` · <span class="err">연결 오류: ${esc(S.errors.join(" / "))}</span>` : "";
  const hint = ((S.mode==="wallpaper" || S.underIcons) && !S.editing && S.hotkeyEdit) ? ` · ${esc(S.hotkeyEdit.replace("CommandOrControl","Ctrl"))} 편집` : "";
  $("status").innerHTML = (DEMO?`<span class="badge">데모 데이터</span> `:"") + (S.syncing?"동기화 중…":`마지막 동기화 ${up}`) + hint + err;
  $("syncBtn").classList.toggle("spin", !!S.syncing);
  $("syncBtn2").classList.toggle("spin", !!S.syncing);
}

// ---------------- 배치 ----------------
function layout(){
  const P = S.panels||{}, widget = S.mode==="widget";
  const showClock = P.clock!==false, showNext = P.next!==false, showTools = P.toolbar!==false;
  const head = showClock||showNext||showTools;
  let agenda = P.list!==false && (P.today!==false || P.tomorrow!==false || P.memo!==false);
  const cal = P.calendar!==false, foot = P.footer!==false;
  if (widget && agenda && cal && innerWidth<720) agenda = false;
  $("header").classList.toggle("hide", !head);
  document.querySelector(".clockbox").classList.toggle("hide", !showClock);
  $("next").classList.toggle("hide", !showNext);
  $("toolbar").classList.toggle("hide", !showTools);
  document.querySelector(".right").classList.toggle("hide", !showNext && !showTools);
  $("agenda").classList.toggle("hide", !agenda);
  $("main").classList.toggle("hide", !cal);
  $("footer").classList.toggle("hide", !foot);
  $("lockBtn").classList.toggle("hide", !widget);
  $("agenda").classList.toggle("with-cal", agenda && cal);
  $("listBtn").setAttribute("aria-pressed", P.list!==false);
  $("calBtn").setAttribute("aria-pressed", P.calendar!==false);
  const two = agenda && cal, areas = [], rows = [];
  if (head){ areas.push(two?'"head head"':'"head"'); rows.push("auto"); }
  const rightList = A().listSide === "right";
  if (two){ areas.push(rightList ? '"cal agenda"' : '"agenda cal"'); rows.push("minmax(0,1fr)"); }
  else if (agenda){ areas.push('"agenda"'); rows.push("minmax(0,1fr)"); }
  else if (cal){ areas.push('"cal"'); rows.push("minmax(0,1fr)"); }
  if (foot){ areas.push(two?'"foot foot"':'"foot"'); rows.push("auto"); }
  const shell = $("shell");
  shell.style.gridTemplateAreas = areas.join(" ");
  shell.style.gridTemplateRows = rows.join(" ");
  const lw = listWidth();
  const listCol = lw ? `${lw}px` : (widget ? "17rem" : "minmax(19rem,30%)");
  shell.style.gridTemplateColumns = two ? (rightList ? `minmax(0,1fr) ${listCol}` : `${listCol} minmax(0,1fr)`) : "1fr";
  $("agenda").classList.toggle("right", two && rightList);
  $("header").style.justifyContent = showClock ? "space-between" : "flex-end";
  $("split").classList.toggle("hide", !two);
  if (two) requestAnimationFrame(placeSplit);
}
// ---------------- 목록 ↔ 달력 너비 (가운데 경계 끌기) ----------------
const listKey = () => S.mode==="widget" ? "listWidthWidget" : "listWidthWall";
function listWidth(){
  const v = Number(A()[listKey()]); if (!v) return 0;
  const max = Math.max(220, $("shell").clientWidth - 380);
  return Math.round(Math.min(Math.max(v, 200), max));
}
function placeSplit(){
  const sp = $("split"), ag = $("agenda"), sh = $("shell");
  if (sp.classList.contains("hide")) return;
  const a = ag.getBoundingClientRect(), r = sh.getBoundingClientRect(), m = $("main").getBoundingClientRect();
  const mid = A().listSide === "right" ? (m.right + a.left)/2 : (a.right + m.left)/2;
  sp.style.left = (mid - r.left - 6) + "px";
  sp.style.top = (a.top - r.top) + "px"; sp.style.height = a.height + "px";
}
(function setupSplit(){
  const sp = $("split"); let st = null, raf = 0, cur = 0;
  sp.addEventListener("pointerdown", ev=>{
    ev.preventDefault(); sp.setPointerCapture(ev.pointerId);
    st = { x: ev.clientX, w: $("agenda").getBoundingClientRect().width };
    document.body.classList.add("resizing");
  });
  sp.addEventListener("pointermove", ev=>{
    if (!st) return;
    const max = Math.max(220, $("shell").clientWidth - 380);
    const right = A().listSide === "right";
    cur = Math.round(Math.min(Math.max(st.w + (right ? -1 : 1) * (ev.clientX - st.x), 200), max));
    $("shell").style.gridTemplateColumns = right ? `minmax(0,1fr) ${cur}px` : `${cur}px minmax(0,1fr)`;
    if (!raf) raf = requestAnimationFrame(()=>{ raf = 0; placeSplit(); renderMain(); });
  });
  const end = ()=>{
    if (!st) return; st = null; document.body.classList.remove("resizing");
    if (cur){ S.appearance = { ...A(), [listKey()]: cur }; API && API.patchAppearance && API.patchAppearance({ [listKey()]: cur }); applyState({}); }
  };
  sp.addEventListener("pointerup", end); sp.addEventListener("pointercancel", end);
  sp.addEventListener("dblclick", ()=>{ S.appearance = { ...A(), [listKey()]: 0 }; API && API.patchAppearance && API.patchAppearance({ [listKey()]: 0 }); applyState({}); });
})();

function applyState(s){
  S = {...S, ...s};
  if (s.appearance && window.DeskTheme) DeskTheme.apply(s.appearance);
  parsed = (S.events||[]).map(parse);
  holidays = new Map();
  parsed.filter(e=>e.holiday).forEach(e=>{ for(let d=startOfDay(e.s); d<e.e2; d=addDays(d,1)){ const k=ymd(d); holidays.set(k, holidays.has(k)? holidays.get(k)+", "+e.title : e.title); } });
  const a = A(), widget = S.mode==="widget";
  document.body.className = [widget?"widget":"wallpaper", S.editing?"editing":"", S.locked?"locked":"", S.minimal?"minimal":"", S.underIcons?"under":"", S.pinned?"pinned":"", !widget && a.wallpaperAlign && a.wallpaperAlign!=="full" ? "align-"+a.wallpaperAlign : ""].join(" ");
  const gutter = widget ? 0 : (S.iconGutter??170);
  document.documentElement.style.setProperty("--icon-gutter", gutter+"px");
  document.documentElement.style.setProperty("--ww", `calc((100vw - ${gutter}px) * ${(a.wallpaperWidth||72)/100})`);
  document.querySelectorAll(".seg button").forEach(b=>b.setAttribute("aria-pressed", b.dataset.v===S.view));
  $("lockBtn").classList.toggle("on", !!S.locked);
  $("lockBtn").setAttribute("aria-pressed", !!S.locked);
  $("lockPath").setAttribute("d", S.locked ? "M8 11V7a4 4 0 0 1 8 0v4" : "M8 11V7a4 4 0 0 1 8 0");
  $("lockBtn").dataset.tip = S.locked ? "잠금 해제" : "위치·크기 잠금";
  layout();
  renderClock(); renderAgenda(); renderMain(); renderFooter(); renderMini(); renderOpacity();
  $("setBtn").classList.toggle("upd", !!S.updateAvailable);
  $("setBtn").dataset.tip = S.updateAvailable ? `설정 · 새 버전 ${S.updateAvailable} 업데이트 가능` : "설정";
  $("editMsg").textContent = S.autoEdit ? "편집 중 · 다른 곳을 누르면 바탕화면으로 돌아가요" : "편집 모드 · 일정을 추가·수정하거나 위젯을 옮길 수 있어요";
  placeWallGrip(); applyDeco(); setupAutoTalk();
}
// 시즌 혼합 컬렉션: 앱을 켤 때마다 다른 조합 + 한 시간마다 섞임 (응원 친구를 세 번 연속 누르면 다시 섞기)
let mixSalt = Math.floor(Math.random() * 1e6), mixTaps = [];
function maybeReshuffle(){
  const t = window.DeskThemes && DeskThemes.actual(A().theme, NOW());
  if (!(t && t.season && !t.char) || (CH().seasonPet || "mix") !== "mix") return;
  const now = Date.now(); mixTaps = mixTaps.filter(x=>now-x<1500); mixTaps.push(now);
  if (mixTaps.length >= 3){ mixTaps = []; mixSalt++; setTimeout(()=>{ lookKey = ""; applyDeco(); }, 450); }
}
// Linaverse·시즌 테마: 바탕 무늬 + 은은한 모서리 캐릭터 + 날짜 옆 응원 캐릭터 + 명절 배너
let lookKey = "";
function applyDeco(){
  const t = window.DeskThemes && DeskThemes.actual(A().theme, NOW());
  const charTheme = !!(t && (t.char || t.season));
  const on = charTheme && A().deco !== false;
  document.body.classList.toggle("deco", on);
  const lk = charTheme && CH().enabled !== false ? Chars.lookFor(A(), CH(), NOW(), null, { salt: mixSalt }) : null;
  const key = (t ? t.id : "") + "|" + JSON.stringify(lk) + "|" + on + "|" + A().decoChar + "|" + CH().clock;
  if (key === lookKey) return;
  lookKey = key;
  // 날짜 옆 친구 (누르면 반응)
  const bd = $("buddy");
  if (lk && CH().clock !== false){ bd.src = lk.src; bd.dataset.c = lk.id; bd.classList.remove("hide"); bd.classList.toggle("wide", !!lk.holiday); bd.title = `${Chars.byId(lk.id).name} 친구 · 눌러 보세요`; }
  else { bd.classList.add("hide"); bd.removeAttribute("data-c"); }
  // 명절·새해 인사 배너
  const bn = $("banner");
  if (lk && lk.banner){ bn.src = lk.banner; bn.classList.remove("hide"); } else bn.classList.add("hide");
  // 바탕 무늬 + 모서리 캐릭터(은은하게)
  if (on){
    document.documentElement.style.setProperty("--deco-pat", DeskThemes.patternFor(t, t.dark ? 0.06 : 0.09));
    const dc = $("dchar");
    if (lk && A().decoChar !== false){ dc.src = (lk.corner || lk).src; dc.classList.remove("hide"); } else dc.classList.add("hide");
  }
}
function placeWallGrip(){
  const g = document.querySelector(".wgrip"); if (!g) return;
  const r = $("shell").getBoundingClientRect(), al = A().wallpaperAlign;
  g.style.left = (al==="right" ? r.left : r.right) + "px";
}

// ---------------- 미니 달력 ----------------
function renderMini(){
  if (!S.minimal) return;
  const t = NOW(), today0 = startOfDay(t), y = cursor.getFullYear(), m = cursor.getMonth();
  const first = new Date(y,m,1), lead = (first.getDay()-weekStart()+7)%7, start = addDays(first,-lead);
  const weeks = Math.ceil((lead+new Date(y,m+1,0).getDate())/7);
  $("miniTitle").innerHTML = `${m+1}월<span>${y}</span>`;
  let html = orderWD().map(i=>`<div class="h ${i===0?"sun":i===6?"sat":""}">${WD[i]}</div>`).join("");
  for (let i=0;i<weeks*7;i++){
    const d = addDays(start,i), list = eventsOn(d), hol = holidayOn(d);
    const cls = ["md", d.getMonth()!==m?"other":"", sameDay(d,t)?"today":"", d<today0?"past":"", d.getDay()===0?"sun":d.getDay()===6?"sat":"", hol?"hol":""].join(" ");
    const tip = [hol, ...list.map(e=>`${e.allDay?"종일":tm(e.s)} ${e.title}`)].filter(Boolean).join("\n");
    html += `<div class="${cls}" role="gridcell" data-day="${ymd(d)}" title="${esc(tip)}" aria-label="${esc(`${d.getMonth()+1}월 ${d.getDate()}일, 일정 ${list.length}건`)}"><b>${d.getDate()}</b><span class="pd">${list.slice(0,3).map(e=>`<i style="background:${e.color}"></i>`).join("")}</span></div>`;
  }
  $("mgrid").innerHTML = html;
  const n = NOW(), nx = parsed.filter(e=>!e.allDay && !e.holiday && e.e2>n).sort((a,b)=>a.s-b.s)[0];
  $("miniFoot").innerHTML = nx ? `${nx.s<=n?"지금":"다음"} <b>${sameDay(nx.s,n)?"":`${nx.s.getMonth()+1}/${nx.s.getDate()} `}${tm(nx.s)}</b> ${esc(nx.title)}` : "예정된 일정이 없어요";
}
function setMinimal(on){ if (API && API.setMinimal) API.setMinimal(on); else { S.minimal = on; applyState({}); } }
function togglePanel(k){
  if (API) return API.togglePanel(k);
  const P = S.panels = {...(S.panels||{})};
  P[k] = P[k]===false;
  if (P.list===false && P.calendar===false) P[k==="list"?"calendar":"list"] = true;
  applyState({});
}

// ---------------- 팝오버 ----------------
function closePop(){ $("popHost").innerHTML = ""; }
function openPop(html, anchor){
  $("popHost").innerHTML = `<div class="pop" role="dialog">${html}</div>`;
  const pop = document.querySelector(".pop"), r = anchor.getBoundingClientRect();
  let x = r.left, y = r.bottom + 6;
  const w = pop.offsetWidth, h = pop.offsetHeight;
  if (x + w > innerWidth - 8) x = innerWidth - w - 8;
  if (y + h > innerHeight - 8) y = Math.max(8, r.top - h - 6);
  pop.style.left = x+"px"; pop.style.top = y+"px";
  const f = pop.querySelector("button"); if (f) f.focus({preventScroll:true});
}
function openDayPop(dateStr, anchor){
  const d = new Date(dateStr+"T00:00:00"), list = eventsOn(d), hol = holidayOn(d);
  const rows = list.length ? withNowLine(list, d, e=>evRow(e,d)) : `<div class="empty">일정이 없어요</div>`;
  openPop(`<h3><span>${d.getMonth()+1}월 ${d.getDate()}일 ${WD[d.getDay()]}요일${hol?` <span style="color:var(--sun);font-size:.8rem">${esc(hol)}</span>`:""}</span><button class="btn primary" data-new="${dateStr}" style="padding:.3rem .7rem">+ 추가</button></h3><div class="list">${rows}</div>`, anchor);
}
let mpYear = 0;
let mpAnchor = null;
function drawMonthPicker(){
  const t = NOW();
  openPop(`<div class="mp-y"><button class="navb" data-mp="-1" aria-label="이전 해">‹</button><b>${mpYear}년</b><button class="navb" data-mp="1" aria-label="다음 해">›</button></div>
    <div class="mp-g">${Array.from({length:12},(_,i)=>`<button data-mm="${i}" class="${mpYear===cursor.getFullYear()&&i===cursor.getMonth()?"cur":""} ${mpYear===t.getFullYear()&&i===t.getMonth()?"now":""}">${i+1}월</button>`).join("")}</div>`, mpAnchor || $("title"));
}
function openMonthPicker(anchor){ mpAnchor = anchor || $("title"); mpYear = cursor.getFullYear(); drawMonthPicker(); }
function showKeys(){
  openPop(`<h3>단축키</h3><div class="keys">
    <kbd>← →</kbd><span>이전 · 다음 달(주)</span><kbd>T</kbd><span>오늘로 돌아가기</span><kbd>M / W</kbd><span>월간 · 주간 보기</span>
    <kbd>N</kbd><span>새 메모·일정</span><kbd>L / C</kbd><span>목록 · 달력 패널 켜고 끄기</span><kbd>Z</kbd><span>미니 달력 모드</span><kbd>R</kbd><span>지금 동기화</span><kbd>방향키</kbd><span>날짜 칸 사이 이동 (날짜를 선택한 상태)</span>
    <kbd>Enter</kbd><span>선택한 날짜에 일정 추가</span><kbd>Space</kbd><span>선택한 날짜 일정 보기</span><kbd>Esc</kbd><span>닫기 · 편집 모드 끝내기</span></div>`, $("helpBtn"));
}

// ---------------- 동작 ----------------
const go = dir => { cursor = (S.view==="week" && !S.minimal) ? addDays(cursor, 7*dir) : new Date(cursor.getFullYear(),cursor.getMonth()+dir,1); renderMain(); renderMini(); };
const goToday = () => { cursor = NOW(); renderMain(); renderMini(); const c=document.querySelector('[aria-current="date"]'); if(c) c.focus({preventScroll:true}); };
let toastT = null;
function stickerToast(st){
  const box = $("toast");
  const line = st.isNew ? `새 친구예요 · 도감 ${st.count}/12` : `도감 ${st.count}/12`;
  box.innerHTML = `<img class="chr" src="${Chars.img(st.id)}" alt=""><div><b>${esc(Chars.josa(st.name,"이","가"))} 스티커를 붙여 줬어요</b><small>${esc(line)}</small></div>`;
  box.classList.add("show");
  clearTimeout(toastT); toastT = setTimeout(()=>box.classList.remove("show"), 3800);
}
const setView = v => { S.view=v; API && API.setView(v); applyState({}); };
const newEvent = date => API && API.openEditor(date ? {date} : {});

document.addEventListener("click", ev=>{
  const t = ev.target;
  const mp = t.closest("[data-mp]"); if (mp){ mpYear += Number(mp.dataset.mp); drawMonthPicker(); return; }
  const mm = t.closest("[data-mm]"); if (mm){ cursor = new Date(mpYear, Number(mm.dataset.mm), 1); closePop(); renderMain(); renderMini(); return; }
  const nw = t.closest("[data-new]"); if (nw){ const d = nw.dataset.new; closePop(); newEvent(d); return; }
  const tg = t.closest("[data-toggle]"); if (tg){ if (API) API.toggleNote(tg.dataset.toggle).then(r=>{ if (r && r.sticker) stickerToast(r.sticker); }); return; }
  const nt = t.closest("[data-note]"); if (nt){ API && API.openEditor({noteId:nt.dataset.note}); return; }
  if (t.closest("[data-addmemo]")){ API.stickyNew(); return; }
  const item = t.closest("[data-id]"); if (item){ closePop(); API && API.openEditor({eventId:item.dataset.id}); return; }
  const day = t.closest("[data-day]"); if (day){ openDayPop(day.dataset.day, day); return; }
  if (!t.closest(".pop") && !t.closest("#title") && !t.closest("#miniTitle") && !t.closest("#helpBtn")) closePop();
});
document.addEventListener("dblclick", ev=>{
  if (ev.target.closest("[data-id],[data-day],.pop")) return;
  const cell = ev.target.closest("[data-date]"); if (cell) quickAdd(cell.dataset.date);
});
$("next").onclick = () => nextId && API && API.openEditor({eventId:nextId});
$("addBtn").onclick = () => newEvent();
$("stickyBtn").onclick = () => API.stickyNew();
$("aiBtn").onclick = () => API.aiOpen();
$("syncBtn").onclick = $("syncBtn2").onclick = () => API && API.syncNow();
$("setBtn").onclick = () => API && API.openSettings();
$("helpBtn").onclick = e => { e.stopPropagation(); document.querySelector(".pop .keys") ? closePop() : showKeys(); };
$("lockBtn").onclick = () => API && API.widgetAction(S.locked ? "unlock" : "lock");
$("doneEdit").onclick = () => API && API.setEditing(false);
$("title").onclick = e => { e.stopPropagation(); document.querySelector(".pop .mp-g") ? closePop() : openMonthPicker(); };
document.querySelectorAll(".seg button").forEach(b=> b.onclick = () => setView(b.dataset.v));
$("listBtn").onclick = () => togglePanel("list");
$("calBtn").onclick = () => togglePanel("calendar");
$("miniBtn").onclick = () => setMinimal(true);
$("miniExpand").onclick = () => setMinimal(false);
$("miniPrev").onclick = () => go(-1);
$("miniNext").onclick = () => go(1);
$("miniTitle").onclick = e => { e.stopPropagation(); document.querySelector(".pop .mp-g") ? closePop() : openMonthPicker($("miniTitle")); };
$("prev").onclick = () => go(-1);
$("nextBtn").onclick = () => go(1);
$("todayBtn").onclick = goToday;
// 투명도 막대 (맨 아래)
function renderOpacity(){
  const v = Math.round((S.opacity ?? 1) * 100);
  if (document.activeElement !== $("opRange")) $("opRange").value = v;
  $("opVal").textContent = $("opRange").value + "%";
  document.body.classList.toggle("clear", !!S.opacityCss);
  document.documentElement.style.setProperty("--bga", S.opacityCss ? (Number($("opRange").value)/100) : 1);
}
$("opRange").addEventListener("input", ()=>{ const v = Number($("opRange").value)/100; $("opVal").textContent = $("opRange").value + "%"; if (S.opacityCss) document.documentElement.style.setProperty("--bga", v); API.setOpacity(v, false); });
$("opRange").addEventListener("change", ()=> API.setOpacity(Number($("opRange").value)/100, true));

document.addEventListener("keydown", e=>{
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  const ae = document.activeElement;
  const cell = ae && ae.matches && ae.matches("[data-date][role=gridcell]") ? ae : null;
  if (cell && ["ArrowLeft","ArrowRight","ArrowUp","ArrowDown","Enter"," "].includes(e.key)){
    e.preventDefault();
    if (e.key==="Enter") return newEvent(cell.dataset.date);
    if (e.key===" ") return openDayPop(cell.dataset.date, cell);
    const step = {ArrowLeft:-1, ArrowRight:1, ArrowUp:-7, ArrowDown:7}[e.key];
    const nd = addDays(new Date(cell.dataset.date+"T00:00:00"), step);
    let target = document.querySelector(`[data-date="${ymd(nd)}"][role=gridcell]`);
    if (!target || target.classList.contains("other")){ cursor = nd; renderMain(); target = document.querySelector(`[data-date="${ymd(nd)}"][role=gridcell]`); }
    if (target){ document.querySelectorAll("[role=gridcell]").forEach(c=>c.tabIndex=-1); target.tabIndex=0; target.focus(); }
    return;
  }
  if (e.target.matches && e.target.matches("input,textarea,select")) return;
  const k = e.key;
  if (k==="Escape"){ if (document.querySelector(".pop")) return closePop(); if (S.editing && API) API.setEditing(false); return; }
  if (k==="ArrowLeft") go(-1);
  else if (k==="ArrowRight") go(1);
  else if (k==="t"||k==="T"||k==="Home") goToday();
  else if (k==="m"||k==="M") setView("month");
  else if (k==="w"||k==="W") setView("week");
  else if (k==="n"||k==="N") newEvent();
  else if ((k==="r"||k==="R") && API) API.syncNow();
  else if (k==="?") showKeys();
  else if (k==="l"||k==="L") togglePanel("list");
  else if (k==="c"||k==="C") togglePanel("calendar");
  else if (k==="z"||k==="Z") setMinimal(!S.minimal);
});
addEventListener("resize", () => applyState({}));
document.addEventListener("appearance", ev => { if (ev.detail && JSON.stringify(ev.detail)!==JSON.stringify(S.appearance)) { S.appearance = ev.detail; applyState({}); } });

// ---------------- 빠른 추가 (날짜 칸 더블클릭 → 그 자리에서 바로 입력) ----------------
function writableSource(){
  const ws = (S.sources||[]).filter(s=>s.writable);
  return ws.find(s=>s.id===S.lastWriteSource) || ws[0] || null;
}
function quickParse(text, dateStr){
  const base = new Date(dateStr+"T00:00:00");
  const r = window.DateSense ? DateSense.parse(text, base) : null;
  let title = text;
  if (r && r.parts) r.parts.forEach(p=>{ title = title.replace(p, " "); });
  title = title.replace(/\s+/g," ").replace(/^[\s,·~-]+|[\s,·~-]+$/g,"").trim() || text.trim();
  const date = r ? r.date : dateStr, start = r && r.start, end = r && (r.end || (start ? addMin(start, 60) : null));
  return { title, date, start, end };
}
const addMin = (t, m) => { const [h,mm] = t.split(":").map(Number), x = Math.min(23*60+59, h*60+mm+m); return `${pad(Math.floor(x/60))}:${pad(x%60)}`; };
function quickAdd(dateStr){
  if (!API) return;
  const src = writableSource();
  if (!src){ showToast("쓸 수 있는 캘린더가 없어요", "설정 › 캘린더 연결에서 '내 PC'나 네이버를 켜 주세요"); return; }
  const anchor = document.querySelector(`.cell[data-date="${dateStr}"], .week [data-date="${dateStr}"], .md[data-day="${dateStr}"]`) || $("main");
  const d = new Date(dateStr+"T00:00:00");
  openPop(`<h3><span>${d.getMonth()+1}월 ${d.getDate()}일 ${WD[d.getDay()]}요일</span><span class="qa-src">${esc(src.name)}</span></h3>
    <input id="qa" class="qa-in" placeholder="예) 3시 치과 · 오후 2시~4시 면접" aria-label="새 일정" autocomplete="off">
    <div class="qa-hint" id="qaHint">시간을 안 적으면 종일 일정이에요</div>
    <div class="qa-acts"><span class="kbd">Enter 저장 · Esc 닫기</span><span class="sp"></span><button class="btn" data-qamore>자세히</button><button class="btn primary" data-qasave>저장</button></div>`, anchor);
  const pop = document.querySelector(".pop"); pop.classList.add("qa"); pop.dataset.date = dateStr;
  const inp = $("qa"); inp.focus();
  inp.addEventListener("input", ()=>{
    const v = inp.value.trim(); if (!v){ $("qaHint").textContent = "시간을 안 적으면 종일 일정이에요"; return; }
    const q = quickParse(v, dateStr), qd = new Date(q.date+"T00:00:00");
    const when = `${qd.getMonth()+1}/${qd.getDate()}(${WD[qd.getDay()]}) ${q.start ? `${q.start}~${q.end}` : "종일"}`;
    $("qaHint").innerHTML = `<b>${esc(when)}</b> · ${esc(q.title)}`;
  });
  inp.addEventListener("keydown", e=>{ if (e.key==="Enter" && !e.isComposing){ e.preventDefault(); quickSave(); } });
}
let qaSaving = false;
async function quickSave(){
  const pop = document.querySelector(".pop.qa"); if (!pop || qaSaving) return;
  const v = $("qa").value.trim(); if (!v){ $("qa").focus(); return; }
  const q = quickParse(v, pop.dataset.date), src = writableSource();
  const input = { title: q.title, notes: "", allDay: !q.start, date: q.date, endDate: q.date, startTime: q.start || "09:00", endTime: q.end || "10:00", location: "", categoryChoice: "auto", tz: appTZ() };
  pop.querySelector("[data-qasave]").disabled = true; qaSaving = true;
  try {
    await API.saveEvent({ eventId: null, noteId: null, sourceId: src.id, input });
    closePop();
    const qd = new Date(q.date+"T00:00:00");
    showToast("저장했어요", `${qd.getMonth()+1}/${qd.getDate()} ${q.start||"종일"} · ${q.title}`);
  } catch(err){
    pop.querySelector("[data-qasave]").disabled = false;
    $("qaHint").innerHTML = `<span style="color:var(--danger)">${esc(String(err.message||err).replace(/^Error invoking remote method '[^']+': (Error: )?/,""))}</span>`;
  } finally { qaSaving = false; }
}
// 빠른 추가의 저장 버튼도 누르는 순간 저장 (한글 조합 중 클릭 씹힘 방지)
document.addEventListener("mousedown", ev=>{
  const b = ev.target.closest("[data-qasave]"); if (!b || ev.button !== 0) return;
  ev.preventDefault(); const i = $("qa"); if (i) i.blur();
  setTimeout(quickSave, 30);
});
document.addEventListener("click", ev=>{
  if (ev.target.closest("[data-qasave]")){ if (ev.detail === 0) quickSave(); }
  else if (ev.target.closest("[data-qamore]")){ const pop=document.querySelector(".pop.qa"); const date = pop && pop.dataset.date; const text = $("qa") ? $("qa").value : ""; closePop(); API && API.openEditor({date, text}); }
});
function showToast(title, sub, img){
  const box = $("toast");
  box.innerHTML = `${img?`<img class="chr" src="${img}" alt="">`:""}<div><b>${esc(title)}</b>${sub?`<small>${esc(sub)}</small>`:""}</div>`;
  box.classList.add("show");
  clearTimeout(toastT); toastT = setTimeout(()=>box.classList.remove("show"), 3200);
}

// ---------------- 끌어서 다른 날로 옮기기 ----------------
let dragId = null;
document.addEventListener("dragstart", ev=>{
  const el = ev.target.closest && ev.target.closest("[data-id][draggable=true]"); if (!el) return;
  dragId = el.dataset.id; el.classList.add("dragsrc"); ev.dataTransfer.effectAllowed = "move"; ev.dataTransfer.setData("text/plain", dragId);
  setTimeout(()=>document.body.classList.add("dragging"), 0);
});
document.addEventListener("dragend", ()=>{ dragId = null; document.querySelectorAll(".dragsrc").forEach(x=>x.classList.remove("dragsrc")); document.body.classList.remove("dragging"); document.querySelectorAll(".drop").forEach(x=>x.classList.remove("drop")); });
document.addEventListener("dragover", ev=>{
  if (!dragId) return;
  const cell = ev.target.closest("[data-date]"); if (!cell) return;
  ev.preventDefault(); ev.dataTransfer.dropEffect = "move";
  document.querySelectorAll(".drop").forEach(x=>{ if (x!==cell) x.classList.remove("drop"); });
  cell.classList.add("drop");
});
document.addEventListener("drop", async ev=>{
  const cell = ev.target.closest("[data-date]"); if (!dragId || !cell) return;
  ev.preventDefault();
  const id = dragId; dragId = null; cell.classList.remove("drop"); closePop();
  const e = parsed.find(x=>x.id===id); if (!e) return;
  const days = Math.round((new Date(cell.dataset.date+"T00:00:00") - startOfDay(e.s)) / 864e5);
  if (days) moveEvent(e, days);
});
async function moveEvent(e, days){
  // 화면에서 먼저 옮겨 보이고, 저장은 뒤에서
  const sh = iso => e.allDay ? ymd(addDays(new Date(iso+"T00:00:00"), days)) : new Date(new Date(iso).getTime()+days*864e5).toISOString();
  const raw = (S.events||[]).find(x=>x.id===e.id);
  const before = raw && {...raw};
  if (raw){ raw.start = sh(raw.start); raw.end = sh(raw.end); applyState({}); }
  try { await API.moveEvent(e.id, days); const d = addDays(e.s, days); showToast("옮겼어요", `${e.title} → ${d.getMonth()+1}/${d.getDate()}(${WD[d.getDay()]})`); }
  catch(err){ if (raw && before) Object.assign(raw, before); applyState({}); showToast("옮기지 못했어요", String(err.message||err).replace(/^Error invoking remote method '[^']+': (Error: )?/,"")); }
}

// ---------------- 오른쪽 클릭 메뉴 ----------------
document.addEventListener("contextmenu", ev=>{
  if (!API || ev.target.closest("input,textarea")) return;
  ev.preventDefault();
  const t = ev.target;
  const evEl = t.closest("[data-id]"), noteEl = t.closest("[data-note],[data-toggle]"), dayEl = t.closest("[data-date],[data-day]");
  if (evEl) API.contextMenu({ kind:"event", id: evEl.dataset.id });
  else if (noteEl) API.contextMenu({ kind:"note", id: noteEl.dataset.note || noteEl.dataset.toggle });
  else if (dayEl) API.contextMenu({ kind:"day", date: dayEl.dataset.date || dayEl.dataset.day });
  else API.contextMenu({ kind:"none" });
});
API && API.onCtxAction && API.onCtxAction(a=>{
  if (a.action==="today") goToday();
  else if (a.action==="quick") quickAdd(a.date);
  else if (a.action==="daypop"){ const el = document.querySelector(`[data-day="${a.date}"]`); if (el) openDayPop(a.date, el); }
  else if (a.action==="move"){ const e = parsed.find(x=>x.id===a.id); if (e) moveEvent(e, a.days); }
  else if (a.action==="toggle"){ API.toggleNote(a.id).then(r=>{ if (r && r.sticker) stickerToast(r.sticker); }); }
  else if (a.action==="error") showToast("처리하지 못했어요", a.message);
});

// ---------------- 바탕화면에 박힌 상태에서 바로 클릭 ----------------
// 동기화·달 넘기기·메모 체크 같은 가벼운 동작은 그 자리에서 바로,
// 일정 열기·날짜 칸 더블클릭(빠른 추가)은 편집 상태로 꺼내면서 바로 실행
let lastDesk = { t:0, key:"" };
const sleep = ms => new Promise(r=>setTimeout(r, ms));
async function activateThen(fn){
  await API.activate();
  await sleep(220);
  await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
  fn();
}
function selectorOf(el){
  if (el.id) return "#"+CSS.escape(el.id);
  for (const k of ["id","day","note","toggle","date","v","new"]) if (el.dataset && el.dataset[k]!=null) return `[data-${k}="${CSS.escape(el.dataset[k])}"]`;
  if (el.hasAttribute && el.hasAttribute("data-addmemo")) return "[data-addmemo]";
  return null;
}
API && API.onDeskClick && API.onDeskClick(async p=>{
  if (S.editing) return;
  const el = document.elementFromPoint(p.x, p.y); if (!el) return;
  hoverAt(null);
  // 응원 친구는 그 자리에서 반응만
  const bd = el.closest("#buddy"); if (bd){ petReact(bd); return; }
  // 첫 번째 클릭: 편집 모드로 꺼내기만 (일정·날짜 창은 열지 않음) → 한 번 더 누르면 그때 열림
  const target = el.closest("[data-id],[data-day],[data-note],[data-date],button,input,select,label");
  if (target) window.DeskTheme && DeskTheme.press(target);
  await API.activate();
});
// 바탕화면에 붙어 있을 때도 마우스를 올리면 설명이 나오게 (메인이 마우스 위치를 알려 줌)
let hoverEl = null;
function hoverAt(p){
  const el = p ? document.elementFromPoint(p.x, p.y) : null;
  const t = el && el.closest ? el.closest("button,[role=button],[data-tip]") : null;
  if (t === hoverEl) return;
  if (hoverEl) hoverEl.dispatchEvent(new MouseEvent("mouseout", { bubbles:true }));
  hoverEl = t;
  (t || document.body).dispatchEvent(new MouseEvent("mouseover", { bubbles:true }));
}
API && API.onDeskHover && API.onDeskHover((p)=>{ if (!S.editing) hoverAt(p); });

// ---------------- 마우스로 크기 조절 ----------------
// 위젯: 가장자리·모서리를 끌어서 / 바탕화면(가운데·좌·우 정렬): 안쪽 가장자리를 끌어서 폭 조절
function setupResize(){
  const host = document.createElement("div"); host.id = "grips"; host.setAttribute("aria-hidden","true");
  host.innerHTML = ["n","s","e","w","ne","nw","se","sw"].map(d=>`<div class="rz rz-${d}" data-grip="${d}"></div>`).join("") + `<div class="wgrip" data-wgrip></div>`;
  document.body.appendChild(host);
  let st = null, raf = 0, last = null;
  host.addEventListener("pointerdown", ev=>{
    const g = ev.target.closest("[data-grip],[data-wgrip]"); if (!g || !API) return;
    ev.preventDefault(); g.setPointerCapture(ev.pointerId);
    st = { dir: g.dataset.grip || "wall", sx: ev.screenX, sy: ev.screenY, x: window.screenX, y: window.screenY, w: window.outerWidth, h: window.outerHeight, ww: A().wallpaperWidth||72, align: A().wallpaperAlign };
    document.body.classList.add("resizing");
  });
  host.addEventListener("pointermove", ev=>{
    if (!st) return;
    const dx = ev.screenX - st.sx, dy = ev.screenY - st.sy;
    if (st.dir === "wall"){
      const usable = innerWidth - (S.iconGutter??170);
      const k = st.align==="center" ? 2 : 1, sign = st.align==="right" ? -1 : 1;
      last = { pct: st.ww + sign*dx*k/usable*100 };
    } else {
      let { x, y, w, h } = st;
      if (st.dir.includes("e")) w += dx;
      if (st.dir.includes("s")) h += dy;
      if (st.dir.includes("w")){ x += dx; w -= dx; }
      if (st.dir.includes("n")){ y += dy; h -= dy; }
      const minW = S.minimal?220:320, minH = S.minimal?220:260;
      if (w < minW){ if (st.dir.includes("w")) x -= minW - w; w = minW; }
      if (h < minH){ if (st.dir.includes("n")) y -= minH - h; h = minH; }
      last = { x, y, width: w, height: h };
    }
    if (!raf) raf = requestAnimationFrame(()=>{ raf = 0; if (!last) return; if (last.pct!=null) API.setWallWidth(last.pct); else API.setBounds(last); });
  });
  const end = ()=>{ if (!st) return; if (last){ if (last.pct!=null) API.setWallWidth(last.pct, true); else API.setBounds(last, true); } st = null; last = null; document.body.classList.remove("resizing"); };
  host.addEventListener("pointerup", end); host.addEventListener("pointercancel", end);
}
setupResize();

// ---------------- 시작 ----------------
const CATS=[{id:"work",name:"업무",color:"#5B7DB1"},{id:"meet",name:"약속",color:"#C49A3A"},{id:"personal",name:"개인",color:"#8E6BA6"},{id:"anniv",name:"기념일",color:"#C2637A"},{id:"bday",name:"생일",color:"#6E9B5E"}];
function demo(){
  const t = new Date(); const D=(dd,h,m)=>new Date(t.getFullYear(),t.getMonth(),t.getDate()+dd,h,m).toISOString();
  const Ad = dd => ymd(addDays(t,dd));
  const ev=(id,title,start,end,allDay=false,location="")=>({id:String(id),title,start,end,allDay,location,color:"#888"});
  const list=[ev(1,"주간 업무회의",D(0,9,0),D(0,10,0),false,"본사 12층"),ev(2,"신입 지원자 1차 면접",D(0,11,0),D(0,12,0),false,"화상 면접"),
    ev(3,"친구 점심 약속",D(0,12,30),D(0,13,30)),ev(4,"채용 보고서 마감",D(0,16,0),D(0,17,0)),
    ev(5,"팀 워크숍",Ad(1),Ad(3),true),ev(6,"경력직 2차 면접",D(1,14,0),D(1,15,0)),ev(7,"입사자 오리엔테이션",D(2,9,30),D(2,11,0)),
    ev(8,"치과",D(3,19,0),D(3,20,0)),ev(9,"가족 저녁 약속",D(5,18,0),D(5,20,0)),ev(10,"급여 마감",Ad(10),Ad(11),true),
    ev(11,"면접관 교육",D(-3,10,0),D(-3,12,0)),ev(12,"어머니 생신",Ad(6),Ad(7),true),ev(13,"결혼기념일",Ad(12),Ad(13),true),ev(14,"요가",D(-1,7,0),D(-1,8,0)),{...ev(15,"해외 현장 화상회의",D(0,15,0),D(0,16,0)),tz:"Asia/Riyadh"}]
    .map(e=>{ const c=[["면접","work"],["회의","work"],["마감","work"],["교육","work"],["워크숍","work"],["오리엔테이션","work"],["약속","meet"],["치과","personal"],["요가","personal"],["생신","bday"],["기념일","anniv"]].find(([w])=>e.title.includes(w)); const cat=c&&CATS.find(x=>x.id===c[1]); return cat?{...e,color:cat.color,category:cat.name}:e; });
  list.push({id:"h1",title:"개천절",start:"2026-10-03",end:"2026-10-04",allDay:true,holiday:true,color:"#f00"},{id:"h2",title:"한글날",start:"2026-10-09",end:"2026-10-10",allDay:true,holiday:true,color:"#f00"},{id:"h3",title:"기독탄신일",start:"2026-12-25",end:"2026-12-26",allDay:true,holiday:true,color:"#f00"});
  const notes=[{id:"n1",text:"장보기\n우유, 계란, 사과",color:"var(--accent)",done:false},{id:"n2",text:"면접 질문지 업데이트하기",color:"#4F8BFF",category:"업무",done:false},{id:"n3",text:"생일 선물 아이디어 찾아보기",color:"var(--accent)",done:false},{id:"n4",text:"자동차 보험 갱신 확인",color:"var(--accent)",done:true}];
  list.find(e=>e.id==="12").birthYear = 1962;
  notes[3].sticker = "rabbit";
  const sd = {}; sd[Ad(0)] = ["ox"]; sd[Ad(-2)] = ["tiger","pig"];
  const q = new URLSearchParams(location.search);
  return {characters: q.has("nochar") ? {enabled:false} : {enabled:true, clock:true, deliverer:true, stickers:true, birthday:true}, stickerDays: sd, sources:[{name:"Google",color:"#4F8BFF"}],updated:new Date().toISOString(),errors:[],events:list,notes,categories:CATS,colorBy:"category"};
}
(async ()=>{
  if (API){ API.onState(applyState); applyState(await API.getState()); }
  else {
    DEMO=true; const q=new URLSearchParams(location.search);
    const panels = {}; (q.get("hide")||"").split(",").filter(Boolean).forEach(k=>panels[k]=false);
    const appearance = {theme:q.get("theme")||"midnight", accent:q.get("accent")?"#"+q.get("accent"):((window.DeskThemes && DeskThemes.byId(q.get("theme")||"midnight")||{}).accent||"#D27A4A"), bgColor:q.get("bg")?"#"+q.get("bg"):"", textColor:q.get("fg")?"#"+q.get("fg"):"", deco:!q.has("nodeco"), listSide:q.get("side")||"left", shape:q.get("shape")||"square", font:q.get("font")||"pretendard", fontScale:Number(q.get("scale")||1), weekStart:Number(q.get("ws")||0), timeFormat:q.get("tf")||"24", wallpaperAlign:q.get("align")||"full", wallpaperWidth:Number(q.get("ww")||72), dimPast:true, timeZone:q.get("app")||"system", worldZones:(q.get("zones")||"").split(",").filter(Boolean)};
    if (q.get("month")) cursor = new Date(q.get("month")+"-01T00:00:00");
    applyState({...demo(), mode:q.get("mode")||"wallpaper", view:q.get("view")||"month", editing:q.has("edit"), minimal:q.has("mini"), panels, appearance, iconGutter:Number(q.get("gutter")??170)});
  }
  setInterval(renderClock, 1000);
  // 날짜가 바뀌면(자정) 계절 자동 테마·옷·배너 다시 맞추기
  let dayKey = ymd(NOW());
  setInterval(()=>{ const k = ymd(NOW()); if (k !== dayKey){ dayKey = k; window.DeskTheme && DeskTheme.apply(A()); lookKey = ""; applyState({}); } }, 60000);
  setInterval(()=>{ renderAgenda(); if (S.view==="week") renderMain(); applyDeco(); }, 60000);
})();
