// DeskCal 시작 파일 — 업데이트로 받은 최신 버전 폴더가 있으면 그걸 실행하고, 없으면 기본 설치본을 실행
// (설치 폴더의 파일을 바꾸지 않고 사용자 폴더에 새 버전을 두는 방식이라, 업데이트 뒤 다시 켜기가 안정적)
const { app } = require('electron');
const fs = require('fs');
const path = require('path');

const BUNDLED = require('./package.json').version;
const newer = (a, b) => {
  const p = (v) => String(v || '').split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0);
  return false;
};
function pick() {
  if (process.env.DESKCAL_NO_UPDATES) return __dirname;
  try {
    const root = path.join(app.getPath('userData'), 'versions');
    const list = fs.readdirSync(root).filter((v) => /^\d+\.\d+\.\d+$/.test(v) && newer(v, BUNDLED)).sort((a, b) => (newer(a, b) ? -1 : 1));
    for (const v of list) {
      const dir = path.join(root, v);
      if (!fs.existsSync(path.join(dir, 'app-main.js')) || !fs.existsSync(path.join(dir, 'package.json'))) continue;
      let fails = 0;
      try { fails = Number(fs.readFileSync(path.join(dir, '.boot'), 'utf8')) || 0; } catch {}
      if (fails >= 2) continue; // 두 번 연속 제대로 못 켜진 버전은 건너뜀 → 이전 버전으로
      try { fs.writeFileSync(path.join(dir, '.boot'), String(fails + 1)); } catch {}
      return dir;
    }
  } catch {}
  return __dirname;
}
const dir = pick();
global.__DESKCAL_BOOT = { dir, bundled: BUNDLED, bundledDir: __dirname };
require(path.join(dir, 'app-main.js'));
