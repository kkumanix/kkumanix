// 프로그램 안에서 새 버전 업데이트
// 1) GitHub(kkumanix/kkumanix · deskcal 폴더)의 latest.json 확인 → 2) 새 버전 zip 내려받기·검사
// 3) 사용자 폴더 versions/<버전> 에 풀어 두기 → 4) 다시 시작 (main.js가 가장 새 버전 폴더를 실행)
//    설치 폴더 파일은 건드리지 않음 → 회사 PC 보안 정책(PowerShell 차단 등)에도 안전
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { execFile } = require('child_process');

// 회사 프록시도 따르도록 Electron(크롬) 네트워크를 우선 사용
const doFetch = (...a) => { try { const { net } = require('electron'); if (net && net.fetch) return net.fetch(...a); } catch {} return fetch(...a); };
const FEED = process.env.DESKCAL_UPDATE_FEED || 'https://raw.githubusercontent.com/kkumanix/kkumanix/main/deskcal/latest.json';
const FEED_API = 'https://api.github.com/repos/kkumanix/kkumanix/contents/deskcal/latest.json';

let cur = '0.0.0', appDir = '', userData = '', bootDir = '', onState = () => {};
let state = { phase: 'idle', latest: null, progress: 0, message: '', checkedAt: 0 };
function init(o) { cur = o.version; appDir = o.appDir; userData = o.userData; bootDir = o.bootDir || o.appDir; onState = o.onState || onState; setTimeout(cleanupOld, 30000); }
const set = (s) => { state = { ...state, ...s }; onState(getState()); };
const getState = () => ({ ...state, current: cur, available: !!(state.latest && newer(state.latest.version, cur)) });

function newer(a, b) {
  const p = (v) => String(v || '').replace(/^v/, '').split('.').map((x) => parseInt(x, 10) || 0);
  const x = p(a), y = p(b);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); }
  return false;
}
const resourcesDir = () => path.dirname(bootDir || appDir);

// 지난번 업데이트에서 남은 것 정리: 예전 방식 폴더(app-next·app-old) + 지금보다 오래된 버전 폴더
const versionsDir = () => path.join(userData, 'versions');
function cleanupOld() {
  for (const n of ['app-next', 'app-old']) { try { fs.rmSync(path.join(resourcesDir(), n), { recursive: true, force: true }); } catch {} }
  try {
    for (const v of fs.readdirSync(versionsDir())) {
      if (/^\d+\.\d+\.\d+$/.test(v) && newer(cur, v)) fs.rmSync(path.join(versionsDir(), v), { recursive: true, force: true });
    }
  } catch {}
}
async function getJSON(url) {
  const r = await doFetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { headers: { 'User-Agent': 'DeskCal-Updater', 'Cache-Control': 'no-cache', Accept: 'application/json' } });
  if (!r.ok) throw new Error(`업데이트 서버 응답 오류 (${r.status})`);
  return r.json();
}
async function check() {
  set({ phase: 'checking', message: '새 버전 확인 중…' });
  try {
    let j;
    try { j = await getJSON(FEED); }
    catch (e1) { // raw 주소가 막히면 GitHub API로 한 번 더
      const c = await getJSON(FEED_API);
      j = JSON.parse(Buffer.from(c.content, 'base64').toString('utf8'));
    }
    if (!j || !j.version || !j.url) throw new Error('업데이트 정보가 비어 있어요');
    set({ phase: 'idle', latest: j, checkedAt: Date.now(), message: newer(j.version, cur) ? `새 버전 ${j.version}이 있어요` : '최신 버전이에요' });
  } catch (e) {
    set({ phase: 'idle', checkedAt: Date.now(), message: '확인하지 못했어요: ' + (e.message || e) });
  }
  return getState();
}

async function download(url, dest, expectSize) {
  const r = await doFetch(url, { headers: { 'User-Agent': 'DeskCal-Updater' }, redirect: 'follow' });
  if (!r.ok || !r.body) throw new Error(`내려받기 실패 (${r.status})`);
  const total = Number(r.headers.get('content-length')) || expectSize || 0;
  const out = fs.createWriteStream(dest);
  const hash = crypto.createHash('sha256');
  let got = 0;
  const reader = r.body.getReader();
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    const b = Buffer.from(value);
    hash.update(b); got += b.length;
    if (!out.write(b)) await new Promise((res) => out.once('drain', res));
    set({ phase: 'download', progress: total ? got / total : 0, message: `새 버전 내려받는 중… ${(got / 1e6).toFixed(1)}${total ? ' / ' + (total / 1e6).toFixed(1) : ''}MB` });
  }
  await new Promise((res, rej) => out.end((e) => (e ? rej(e) : res())));
  return hash.digest('hex');
}
function run(cmd, args) { return new Promise((res, rej) => execFile(cmd, args, { windowsHide: true, maxBuffer: 1 << 24 }, (e) => (e ? rej(e) : res()))); }
async function unzip(zip, dir) {
  fs.rmSync(dir, { recursive: true, force: true });
  fs.mkdirSync(dir, { recursive: true });
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  const tries = [
    () => run('tar', ['-xf', zip, '-C', dir]),
    () => run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath ${q(zip)} -DestinationPath ${q(dir)} -Force`]),
    () => run('unzip', ['-q', '-o', zip, '-d', dir])
  ];
  let last = null;
  for (const t of tries) { try { await t(); if (fs.existsSync(path.join(dir, 'package.json'))) return; } catch (e) { last = e; } }
  throw new Error('압축 풀기 실패' + (last ? ': ' + last.message : ''));
}

// 폴더 복사 (바로가기·.bin 링크는 건너뜀)
const ofs = (() => { try { return require('original-fs'); } catch { return fs; } })(); // .asar 파일도 그냥 파일로
function copyDir(src, dst) {
  ofs.mkdirSync(dst, { recursive: true });
  for (const e of ofs.readdirSync(src, { withFileTypes: true })) {
    if (e.isSymbolicLink() || e.name === '.bin') continue;
    const a = path.join(src, e.name), b = path.join(dst, e.name);
    if (e.isDirectory()) copyDir(a, b); else if (e.isFile()) ofs.copyFileSync(a, b);
  }
}
// 내려받아서 app-next 준비까지 (아직 바꾸지는 않음)
async function prepare() {
  if (!state.latest) await check();
  const L = state.latest;
  if (!L || !newer(L.version, cur)) throw new Error('이미 최신 버전이에요');
  const dir = path.join(userData, 'update');
  fs.mkdirSync(dir, { recursive: true });
  const zip = path.join(dir, `DeskCal-app-${L.version}.zip`);
  const sha = await download(L.url, zip, L.size);
  if (L.sha256 && sha.toLowerCase() !== String(L.sha256).toLowerCase()) { fs.rmSync(zip, { force: true }); throw new Error('내려받은 파일이 손상됐어요. 다시 시도해 주세요'); }
  set({ phase: 'unpack', progress: 1, message: '새 버전 준비 중…' });
  const next = path.join(versionsDir(), L.version);
  await unzip(zip, next);
  if (!fs.existsSync(path.join(next, 'app-main.js'))) throw new Error('새 버전 파일이 올바르지 않아요');
  const pkg = JSON.parse(fs.readFileSync(path.join(next, 'package.json'), 'utf8'));
  if (pkg.version !== L.version) throw new Error(`버전이 맞지 않아요 (${pkg.version})`);
  // 용량이 큰 node_modules는 그대로 옮겨 씀 (zip에 없을 때)
  if (!fs.existsSync(path.join(next, 'node_modules')) && fs.existsSync(path.join(appDir, 'node_modules'))) {
    set({ message: '새 버전 준비 중… (구성 요소 복사)' });
    copyDir(path.join(appDir, 'node_modules'), path.join(next, 'node_modules'));
  }
  // AI 실행 도구도 바뀌지 않았으면 그대로 옮겨 씀
  if (!fs.existsSync(path.join(next, 'ai')) && fs.existsSync(path.join(appDir, 'ai'))) copyDir(path.join(appDir, 'ai'), path.join(next, 'ai'));
  fs.rmSync(zip, { force: true });
  set({ phase: 'ready', message: `${L.version} 준비 완료 · 다시 시작하면 적용돼요` });
  return getState();
}

// 다시 시작 → main.js가 versions 폴더의 새 버전을 실행
function applyAndRestart(app) {
  try { fs.writeFileSync(path.join(versionsDir(), String(state.latest.version), '.boot'), '0'); } catch {}
  app.relaunch();
  app.exit(0);
}

module.exports = { init, check, prepare, applyAndRestart, getState, newer };
