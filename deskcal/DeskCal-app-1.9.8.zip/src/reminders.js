// 다단계 알림: 한 달 전 · 일주일 전 · 하루 전 · 당일 아침 · 시작 N분 전 (+ 다시 알림)
const DAY = 864e5;
const GRACE = 20 * 60 * 1000; // PC가 잠깐 꺼져 있었어도 20분 안이면 알림

function startOf(ev) {
  return ev.allDay ? new Date(ev.start + 'T00:00:00') : new Date(ev.start);
}

const UNIT = { minute: '분', hour: '시간', day: '일', week: '주', month: '달' };

// 일정마다 따로 정한 알림: [{ n, unit, time }]  (time = 'HH:MM', 일·주·달 단위에서만 사용)
function customTriggers(ev, list) {
  const s = startOf(ev);
  const out = [];
  list.forEach((c, i) => {
    const n = Math.max(0, Math.floor(Number(c.n) || 0));
    if (!UNIT[c.unit]) return;
    let at;
    if (c.unit === 'minute') at = new Date(s.getTime() - n * 60000);
    else if (c.unit === 'hour') at = new Date(s.getTime() - n * 3600000);
    else {
      at = new Date(s);
      if (c.unit === 'month') at.setMonth(at.getMonth() - n);
      else at.setDate(at.getDate() - n * (c.unit === 'week' ? 7 : 1));
      if (c.time && /^\d{1,2}:\d{2}$/.test(c.time)) { const [h, m] = c.time.split(':').map(Number); at.setHours(h, m, 0, 0); }
      else if (ev.allDay) at.setHours(9, 0, 0, 0);
    }
    const when = n === 0 ? (c.unit === 'minute' || c.unit === 'hour' ? '지금 시작' : '당일') : `${n}${UNIT[c.unit]} 전`;
    out.push({ kind: `c${i}-${n}${c.unit}${c.time || ''}`, label: `${when} 알림${c.time && !['minute', 'hour'].includes(c.unit) ? ` · ${c.time}` : ''}`, at });
  });
  return out;
}

function triggersFor(ev, r) {
  if (Array.isArray(ev.remind)) return customTriggers(ev, ev.remind);
  const s = startOf(ev);
  const list = [];
  const at9 = (d) => { const x = new Date(d); x.setHours(9, 0, 0, 0); return x; };
  const base = ev.allDay ? at9(s) : s;
  if (r.month) list.push({ kind: 'month', label: '한 달 전 알림', at: new Date(base.getTime() - 30 * DAY) });
  if (r.week) list.push({ kind: 'week', label: '일주일 전 알림', at: new Date(base.getTime() - 7 * DAY) });
  if (r.day) list.push({ kind: 'day', label: '하루 전 알림', at: new Date(base.getTime() - DAY) });
  if (r.sameDay) {
    const m = new Date(s); m.setHours(r.sameDayHour ?? 8, 0, 0, 0);
    if (ev.allDay || m < s) list.push({ kind: 'sameDay', label: '오늘 일정', at: m });
  }
  if (!ev.allDay && r.before > 0) list.push({ kind: 'before', label: `${r.before}분 후 시작`, at: new Date(s.getTime() - r.before * 60000) });
  return list;
}

// 지금 울려야 할 알림 목록을 돌려주고, 상태(state)를 갱신
function due(events, settings, state, now = new Date()) {
  const out = [];
  const r = settings.reminders || {};
  const byId = new Map(events.map((e) => [e.id, e]));
  for (const ev of events) {
    if (startOf(ev).getTime() + DAY < now.getTime()) continue; // 지난 일정
    for (const t of triggersFor(ev, r)) {
      const key = `${ev.id}#${t.kind}`;
      if (state.fired[key]) continue;
      const diff = now - t.at;
      if (diff >= 0 && diff <= GRACE) {
        state.fired[key] = now.getTime();
        out.push({ key, label: t.label, event: ev });
      } else if (diff > GRACE) {
        state.fired[key] = -now.getTime(); // 놓친 알림은 조용히 넘김
      }
    }
  }
  // 다시 알림
  state.snoozes = (state.snoozes || []).filter((sn) => {
    if (sn.at > now.getTime()) return true;
    const ev = byId.get(sn.eventId);
    if (ev) out.push({ key: `${sn.eventId}#snooze#${sn.at}`, label: '다시 알림', event: ev });
    return false;
  });
  // 오래된 기록 정리
  const cutoff = now.getTime() - 45 * DAY;
  for (const k of Object.keys(state.fired)) if (Math.abs(state.fired[k]) < cutoff) delete state.fired[k];
  return out;
}

module.exports = { due, triggersFor, UNIT };
