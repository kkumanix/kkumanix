// 내 PC 안에서 도는 AI (llama.cpp · node-llama-cpp) — 글·메일 → 일정 목록
// 인터넷으로 보내지 않음. 처음 한 번 AI 모델 파일만 내려받음.
const fs = require('fs');
const path = require('path');
const os = require('os');
const { execFile } = require('child_process');
const { pathToFileURL } = require('url');
const DateSense = require('../renderer/datesense.js');
const Lunar = require('../renderer/lunar.js');

const MODELS = [
  { id: 'qwen3-4b', name: '정확하게 (추천)', size: '약 2.5GB', uri: 'hf:unsloth/Qwen3-4B-Instruct-2507-GGUF:Q4_K_M',
    desc: '긴 메일도 잘 알아들어요. 한 번 정리에 20~60초 (PC 성능에 따라)' },
  { id: 'qwen25-1.5b', name: '빠르게', size: '약 1.1GB', uri: 'hf:Qwen/Qwen2.5-1.5B-Instruct-GGUF:Q4_K_M',
    desc: '가볍고 빨라요. 짧은 문장 위주일 때' }
];

let base = null;          // userData
let appDir = null;        // resources/app
let state = { phase: 'idle', progress: 0, message: '' };
let onProgress = () => {};
let mod = null, llama = null, model = null, modelKey = '', idleTimer = null, busy = Promise.resolve();

function init(opts) { base = opts.userData; appDir = opts.appDir; onProgress = opts.onProgress || onProgress; }
const modelsDir = () => path.join(base, 'ai-models');
const runtimeDir = () => process.env.DESKCAL_AI_RUNTIME || path.join(base, 'ai-runtime');
const setState = (s) => { state = { ...state, ...s }; onProgress(state); };

// ---------------------------------------------------------------- AI 실행 도구 준비 (처음 한 번 압축 풀기)
const RT_VERSION = '3.22.2-1';
function runtimeEntry() { return path.join(runtimeDir(), 'node_modules', 'node-llama-cpp', 'dist', 'index.js'); }
function runtimeReady() {
  if (process.env.DESKCAL_AI_RUNTIME) return fs.existsSync(runtimeEntry());
  try { return fs.readFileSync(path.join(runtimeDir(), 'VERSION'), 'utf8').trim() === RT_VERSION && fs.existsSync(runtimeEntry()); } catch { return false; }
}
function packedParts() {
  const dir = path.join(appDir, 'ai');
  try { return fs.readdirSync(dir).filter((f) => /^runtime\.zip\.\d+$/.test(f)).sort().map((f) => path.join(dir, f)); } catch { return []; }
}
async function ensureRuntime() {
  if (runtimeReady()) return;
  const parts = packedParts();
  if (!parts.length) throw new Error('AI 실행 도구(ai 폴더)가 설치 폴더에 없어요');
  setState({ phase: 'unpack', message: 'AI 도구 준비 중 (처음 한 번)…' });
  const zip = path.join(os.tmpdir(), 'deskcal-ai-runtime.zip');
  fs.writeFileSync(zip, Buffer.alloc(0));
  for (const p of parts) fs.appendFileSync(zip, fs.readFileSync(p));
  fs.rmSync(runtimeDir(), { recursive: true, force: true });
  fs.mkdirSync(runtimeDir(), { recursive: true });
  // Windows 10 이상의 tar → 안 되면 PowerShell → (개발용) unzip
  const run = (cmd, args) => new Promise((res, rej) => execFile(cmd, args, { windowsHide: true, maxBuffer: 1 << 24 }, (err) => (err ? rej(err) : res())));
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  const tries = [
    () => run('tar', ['-xf', zip, '-C', runtimeDir()]),
    () => run('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', `Expand-Archive -LiteralPath ${q(zip)} -DestinationPath ${q(runtimeDir())} -Force`]),
    () => run('unzip', ['-q', '-o', zip, '-d', runtimeDir()])
  ];
  let ok = false, last = null;
  for (const t of tries) { try { await t(); if (fs.existsSync(runtimeEntry())) { ok = true; break; } } catch (e) { last = e; } }
  if (!ok) throw new Error('AI 도구 압축 풀기 실패' + (last ? ': ' + last.message : ''));
  fs.rmSync(zip, { force: true });
  fs.writeFileSync(path.join(runtimeDir(), 'VERSION'), RT_VERSION);
}
async function lib() {
  if (mod) return mod;
  await ensureRuntime();
  mod = await import(pathToFileURL(runtimeEntry()).href);
  return mod;
}

// ---------------------------------------------------------------- 모델 파일
function modelFile(settingsAi) {
  const a = settingsAi || {};
  if (a.modelPath && fs.existsSync(a.modelPath)) return a.modelPath;
  const m = MODELS.find((x) => x.id === (a.model || 'qwen3-4b')) || MODELS[0];
  try {
    const dir = path.join(modelsDir(), m.id);
    const f = fs.readdirSync(dir).find((x) => x.endsWith('.gguf') && !x.endsWith('.ipull'));
    return f ? path.join(dir, f) : null;
  } catch { return null; }
}
function status(settingsAi) {
  const f = modelFile(settingsAi);
  let size = 0; try { size = f ? fs.statSync(f).size : 0; } catch {}
  return { models: MODELS, model: (settingsAi && settingsAi.model) || 'qwen3-4b', modelPath: f, modelSize: size,
    runtime: runtimeReady() ? 'ready' : (packedParts().length ? 'packed' : 'missing'), loaded: !!model, ...state };
}
let dl = null;
async function download(id) {
  const m = MODELS.find((x) => x.id === id) || MODELS[0];
  const L = await lib();
  const dir = path.join(modelsDir(), m.id);
  fs.mkdirSync(dir, { recursive: true });
  setState({ phase: 'download', progress: 0, message: `${m.name} 모델 내려받는 중…` });
  dl = await L.createModelDownloader({
    modelUri: m.uri, dirPath: dir, showCliProgress: false, deleteTempFileOnCancel: false,
    onProgress: ({ totalSize, downloadedSize }) => setState({ phase: 'download', progress: totalSize ? downloadedSize / totalSize : 0, message: `${m.name} 모델 내려받는 중… ${(downloadedSize / 1e9).toFixed(2)} / ${(totalSize / 1e9).toFixed(2)}GB` })
  });
  try {
    const p = await dl.download();
    setState({ phase: 'idle', progress: 1, message: '모델 준비 완료' });
    return p;
  } finally { dl = null; }
}
async function cancelDownload() { if (dl) { try { await dl.cancel(); } catch {} setState({ phase: 'idle', message: '내려받기를 멈췄어요 (다시 누르면 이어서 받아요)' }); } }
function deleteModels() { unload(); fs.rmSync(modelsDir(), { recursive: true, force: true }); setState({ phase: 'idle', message: '모델을 지웠어요' }); }

function unload() {
  clearTimeout(idleTimer);
  const m = model; model = null; modelKey = '';
  if (m) m.dispose().catch(() => {});
}
async function loadModel(file) {
  const L = await lib();
  if (!llama) llama = await L.getLlama({ gpu: false, build: 'never', progressLogs: false, logLevel: 'error' });
  if (model && modelKey === file) return model;
  unload();
  setState({ phase: 'load', message: 'AI 모델 불러오는 중…' });
  model = await llama.loadModel({ modelPath: file });
  modelKey = file;
  return model;
}

// ---------------------------------------------------------------- 글 → 일정
const WD = ['일', '월', '화', '수', '목', '금', '토'];
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const SCHEMA = {
  type: 'object',
  properties: {
    events: {
      type: 'array', maxItems: 10,
      items: {
        type: 'object',
        properties: {
          title: { type: 'string' },
          when: { type: 'string' },
          date: { type: 'string' },
          start: { type: 'string' },
          end: { type: 'string' },
          allDay: { type: 'boolean' },
          location: { type: 'string' },
          repeat: { enum: ['none', 'daily', 'weekly', 'monthly', 'yearly'] },
          lunar: { type: 'boolean' }
        }
      }
    }
  }
};
function systemPrompt(now) {
  return [
    '너는 한국어 일정 비서야. 사용자가 준 글(메모·메일·메시지)에서 캘린더에 넣을 일정만 찾아 JSON으로 정리해.',
    `오늘은 ${ymd(now)} (${WD[now.getDay()]}요일)이야.`,
    '규칙:',
    '- title: 일정 이름을 짧게 (예: "경력직 면접", "홍보 회의"). 사람 이름·회사명은 그대로 둬.',
    '- when: 글에 적힌 날짜·시간 표현을 그대로 옮겨 적어 (예: "다음 주 화요일 오후 2시", "11월 20일 10시~12시").',
    '- date: 오늘을 기준으로 계산한 날짜 YYYY-MM-DD. 모르면 "".',
    '- start, end: 24시간 HH:MM. 없으면 "". 시간이 전혀 없으면 allDay를 true로.',
    '- location: 장소. 없으면 "".',
    '- repeat: 매일/매주/매달/매년이라고 적혀 있을 때만 daily/weekly/monthly/yearly, 아니면 none.',
    '- lunar: "음력"이라고 적혀 있으면 true.',
    '- 인사말·서명·안내 문구처럼 일정이 아닌 내용은 넣지 마. 같은 일정을 두 번 넣지 마.'
  ].join('\n');
}
const cleanTime = (t) => { const m = String(t || '').match(/^(\d{1,2}):(\d{2})$/); return m && +m[1] < 24 && +m[2] < 60 ? `${pad(+m[1])}:${m[2]}` : ''; };
const validDate = (d) => /^\d{4}-\d{2}-\d{2}$/.test(d || '') && !isNaN(new Date(d + 'T00:00:00'));

// AI 결과 하나 → 실제 일정 입력값 (날짜 계산은 규칙 엔진으로 한 번 더 확인)
function resolveOne(e, now) {
  const when = String(e.when || '').trim();
  const sense = when ? DateSense.parse(when, now) : null;
  let date = (sense && sense.date) || (validDate(e.date) ? e.date : '');
  let start = (sense && sense.start) || cleanTime(e.start);
  let end = (sense && sense.end) || cleanTime(e.end);
  let lunar = null;
  if (e.lunar || /음력/.test(when)) {
    const m = when.match(/(윤)?\s*(\d{1,2})\s*월\s*(\d{1,2})\s*일?/);
    if (m) {
      lunar = { m: +m[2], d: +m[3], leap: !!m[1] };
      const y = now.getFullYear();
      let s = Lunar.toSolar(y, lunar.m, lunar.d, lunar.leap);
      if (!s || s < ymd(now)) s = Lunar.toSolar(y + 1, lunar.m, lunar.d, lunar.leap);
      if (s) date = s;
    }
  }
  const allDay = !start;
  return {
    title: String(e.title || '').trim() || '(제목 없음)', when, date, startTime: start, endTime: end, allDay,
    location: String(e.location || '').trim(), repeat: e.repeat && e.repeat !== 'none' ? e.repeat : (lunar ? 'yearly' : ''), lunar
  };
}
// 모델이 없을 때: 줄·쉼표로 나눠서 규칙으로만 찾기
function ruleParse(text, now) {
  const segs = String(text || '').split(/\n|[,，;]|(?:\s그리고\s)/).map((s) => s.trim()).filter(Boolean);
  const out = [];
  for (const s of segs) {
    const r = DateSense.parse(s, now);
    if (!r) continue;
    let title = s;
    for (const p of r.parts || []) title = title.replace(p, ' ');
    title = title.replace(/\s*(에|에는|은|는)\s+/g, ' ').replace(/\s+/g, ' ').replace(/^[~\-–·,\s]+|[~\-–·,\s]+$/g, '').trim();
    out.push({ title: title || '(제목 없음)', when: r.found, date: r.date, startTime: r.start || '', endTime: r.end || '', allDay: !r.start, location: '', repeat: '', lunar: null });
  }
  return out;
}

async function analyze(text, settingsAi, now = new Date()) {
  const run = async () => {
    const t0 = Date.now();
    const file = modelFile(settingsAi);
    if (!file || process.env.DESKCAL_AI_RULES) return { events: ruleParse(text, now), usedAI: false, ms: Date.now() - t0 };
    let raw;
    if (process.env.DESKCAL_AI_MOCK) raw = JSON.parse(process.env.DESKCAL_AI_MOCK);
    else {
      const L = await lib();
      const m = await loadModel(file);
      setState({ phase: 'think', message: 'AI가 글을 읽고 있어요…' });
      const ctx = await m.createContext({ contextSize: 4096, threads: Math.max(2, Math.min(8, os.cpus().length - 1)) });
      try {
        const session = new L.LlamaChatSession({ contextSequence: ctx.getSequence(), systemPrompt: systemPrompt(now) });
        const grammar = await llama.createGrammarForJsonSchema(SCHEMA);
        const body = String(text).slice(0, 6000);
        const res = await session.prompt(body, { grammar, maxTokens: 900, temperature: 0.1 });
        raw = grammar.parse(res);
      } finally { await ctx.dispose().catch(() => {}); }
    }
    const events = (raw.events || []).map((e) => resolveOne(e, now)).filter((e) => e.title && (e.date || e.when));
    clearTimeout(idleTimer); idleTimer = setTimeout(unload, 10 * 60 * 1000); // 10분 쉬면 메모리에서 내림
    setState({ phase: 'idle', message: '' });
    return { events, usedAI: true, ms: Date.now() - t0 };
  };
  const p = busy.then(run, run);
  busy = p.catch(() => {});
  try { return await p; } catch (e) { setState({ phase: 'idle', message: '' }); throw e; }
}

module.exports = { init, MODELS, status, download, cancelDownload, deleteModels, analyze, ruleParse, resolveOne, unload, ensureRuntime };
