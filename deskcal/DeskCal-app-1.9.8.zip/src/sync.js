// 캘린더 읽기·쓰기
//  - ics    : Google·Outlook.com 비공개 iCal 주소 (읽기 전용)
//  - caldav : 네이버 캘린더 등 (읽기·쓰기)
//  - local  : 내 PC에만 저장 (읽기·쓰기)
const IcalExpander = require('ical-expander');
const crypto = require('crypto');
const TZ = require('../renderer/tz.js');
const Lunar = require('../renderer/lunar.js');

const DAYS_BACK = 40;
const DAYS_FWD = 400; // 'N달 전' 알림을 위해 1년 이상 앞까지 읽음

const pad = (n) => String(n).padStart(2, '0');
const ymdLocal = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

function range() {
  const now = new Date();
  const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - DAYS_BACK);
  const end = new Date(now.getFullYear(), now.getMonth(), now.getDate() + DAYS_FWD);
  return { start, end };
}

// ---------- 반복 ----------
const REPEAT_TO = { daily: 'DAILY', weekly: 'WEEKLY', monthly: 'MONTHLY', yearly: 'YEARLY' };
const REPEAT_FROM = { DAILY: 'daily', WEEKLY: 'weekly', MONTHLY: 'monthly', YEARLY: 'yearly' };

// 내 PC 반복 일정 → 기간 안의 날짜들로 펼치기
function expandLocal(e, start, end) {
  const allDay = !!e.allDay;
  const at = (v) => (allDay ? new Date(v + 'T00:00:00') : new Date(v));
  const s0 = at(e.start), dur = Math.max(0, at(e.end) - s0);
  if (!REPEAT_TO[e.repeat]) return (s0 < end && new Date(s0.getTime() + dur) > start) ? [e] : [];
  // 매년 음력 반복 (기념일·생일 등): 해마다 음력 날짜를 양력으로 바꿔서
  if (e.repeat === 'yearly' && e.lunar && e.lunar.m) {
    const out = [], until = e.repeatUntil ? new Date(e.repeatUntil + 'T23:59:59') : null;
    for (let y = Math.max(s0.getFullYear(), start.getFullYear() - 1); y <= end.getFullYear() + 1; y++) {
      let v = Lunar.toSolar(y, e.lunar.m, e.lunar.d, e.lunar.leap) || (e.lunar.leap ? Lunar.toSolar(y, e.lunar.m, e.lunar.d, false) : '');
      if (!v) continue;
      const d = new Date(v + 'T00:00:00');
      if (!allDay) d.setHours(s0.getHours(), s0.getMinutes(), 0, 0);
      if (d < new Date(s0.getFullYear(), s0.getMonth(), s0.getDate())) continue;
      if (until && d > until) break;
      if (d >= end) break;
      const de = allDay ? (() => { const x = new Date(d); x.setDate(x.getDate() + Math.max(1, Math.round(dur / 86400000))); return x; })() : new Date(d.getTime() + dur);
      if (de <= start) continue;
      out.push({ ...e, start: allDay ? ymdLocal(d) : d.toISOString(), end: allDay ? ymdLocal(de) : de.toISOString() });
    }
    return out;
  }
  const until = e.repeatUntil ? new Date(e.repeatUntil + 'T23:59:59') : null;
  const fmt = (d) => (allDay ? ymdLocal(d) : d.toISOString());
  const step = e.repeat === 'daily' ? 1 : e.repeat === 'weekly' ? 7 : 0;
  let i = 0;
  if (step) i = Math.max(0, Math.floor((start - s0 - dur) / (step * 86400000)) - 1); // 오래된 반복은 건너뛰기
  const out = [];
  for (let n = 0; n < 1500; n++, i++) {
    const d = new Date(s0);
    if (step) d.setDate(s0.getDate() + i * step);
    else if (e.repeat === 'monthly') { d.setDate(1); d.setMonth(s0.getMonth() + i); d.setDate(s0.getDate()); if (d.getDate() !== s0.getDate()) continue; }
    else { d.setFullYear(s0.getFullYear() + i); if (d.getMonth() !== s0.getMonth()) continue; }
    if (until && d > until) break;
    if (d >= end) break;
    const de = allDay ? (() => { const x = new Date(d); x.setDate(x.getDate() + Math.round(dur / 86400000)); return x; })() : new Date(d.getTime() + dur);
    if (de <= start) continue;
    out.push({ ...e, start: fmt(d), end: fmt(de) });
  }
  return out;
}

// ---------- iCalendar 해석 ----------
function timeToOut(t) {
  if (t.isDate) return { value: `${t.year}-${pad(t.month)}-${pad(t.day)}`, allDay: true };
  return { value: t.toJSDate().toISOString(), allDay: false };
}

function expandIcs(text, src, start, end, extra = {}) {
  const out = [];
  const exp = new IcalExpander({ ics: text, maxIterations: 2000 });
  const { events, occurrences } = exp.between(start, end);
  const push = (item, s, e, recurring) => {
    const S = timeToOut(s);
    // 반복 규칙: 단순한 것(매일·매주·매달·매년, 간격 1)만 DeskCal에서 고칠 수 있음
    let repeat = '', repeatUntil = '', seriesStart = '', seriesEnd = '';
    if (recurring) {
      try {
        const rr = item.component.getFirstPropertyValue('rrule');
        const parts = rr ? Object.keys(rr.parts || {}).filter((k) => (rr.parts[k] || []).length) : [];
        const simple = rr && (!rr.interval || rr.interval === 1) && !rr.count && parts.every((k) => k === 'BYDAY' || k === 'BYMONTHDAY' || k === 'BYMONTH');
        const f = rr && REPEAT_FROM[String(rr.freq || '').toUpperCase()];
        if (simple && f) {
          repeat = f;
          if (rr.until) repeatUntil = `${rr.until.year}-${pad(rr.until.month)}-${pad(rr.until.day)}`;
          seriesStart = timeToOut(item.startDate).value;
          seriesEnd = timeToOut(item.endDate || item.startDate).value;
        }
      } catch { /* 해석 못 하면 읽기 전용 */ }
    }
    let E = e ? timeToOut(e) : S;
    const status = (item.component.getFirstPropertyValue('status') || '').toUpperCase();
    if (status === 'CANCELLED') return;
    // 일정이 저장된 시간대: DeskCal 표시 > TZID > UTC
    let tz = String(item.component.getFirstPropertyValue('x-deskcal-tz') || '');
    if (!tz && !s.isDate) {
      const z = s.timezone || (s.zone && s.zone.tzid) || '';
      tz = z === 'Z' ? 'UTC' : z;
    }
    if (!TZ.valid(tz) || tz === 'floating') tz = '';
    let lunar = null;
    const lv = String(item.component.getFirstPropertyValue('x-deskcal-lunar') || '');
    if (/^\d{1,2}-\d{1,2}-[01]$/.test(lv)) { const [m, d, l] = lv.split('-').map(Number); lunar = { m, d, leap: !!l }; }
    out.push({
      id: `${src.id}|${item.uid}|${S.value}`,
      uid: item.uid,
      sourceId: src.id,
      source: src.name,
      color: src.color,
      title: item.summary || '(제목 없음)',
      start: S.value,
      end: E.value,
      allDay: S.allDay,
      location: item.location || '',
      notes: item.description || '',
      categoryName: String(item.component.getFirstPropertyValue('categories') || ''),
      tz,
      recurring,
      repeat, repeatUntil, seriesStart, seriesEnd, lunar,
      writable: !!extra.writable && (!recurring || !!repeat),
      href: extra.href,
      etag: extra.etag
    });
  };
  events.forEach((ev) => push(ev, ev.startDate, ev.endDate, false));
  occurrences.forEach((o) => push(o.item, o.startDate, o.endDate, true));
  return out;
}

// ---------- iCalendar 만들기 (쓰기용) ----------
const esc = (s) => String(s || '').replace(/\\/g, '\\\\').replace(/;/g, '\\;').replace(/,/g, '\\,').replace(/\r?\n/g, '\\n');
const utcStamp = (d) => d.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');

function buildIcs(ev) {
  const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//DeskCal//KO', 'CALSCALE:GREGORIAN', 'BEGIN:VEVENT',
    `UID:${ev.uid}`, `DTSTAMP:${utcStamp(new Date())}`];
  if (ev.allDay) {
    lines.push(`DTSTART;VALUE=DATE:${ev.start.replace(/-/g, '')}`);
    lines.push(`DTEND;VALUE=DATE:${ev.end.replace(/-/g, '')}`);
  } else {
    lines.push(`DTSTART:${utcStamp(new Date(ev.start))}`);
    lines.push(`DTEND:${utcStamp(new Date(ev.end))}`);
  }
  if (ev.repeat && REPEAT_TO[ev.repeat]) {
    let rule = `RRULE:FREQ=${REPEAT_TO[ev.repeat]}`;
    if (ev.repeatUntil) rule += ev.allDay ? `;UNTIL=${ev.repeatUntil.replace(/-/g, '')}` : `;UNTIL=${utcStamp(new Date(ev.repeatUntil + 'T23:59:59'))}`;
    lines.push(rule);
  }
  lines.push(`SUMMARY:${esc(ev.title)}`);
  if (ev.location) lines.push(`LOCATION:${esc(ev.location)}`);
  if (ev.notes) lines.push(`DESCRIPTION:${esc(ev.notes)}`);
  if (ev.categoryName) lines.push(`CATEGORIES:${esc(ev.categoryName)}`);
  if (ev.tz && !ev.allDay) lines.push(`X-DESKCAL-TZ:${ev.tz}`);
  if (ev.lunar && ev.lunar.m) lines.push(`X-DESKCAL-LUNAR:${ev.lunar.m}-${ev.lunar.d}-${ev.lunar.leap ? 1 : 0}`);
  lines.push('END:VEVENT', 'END:VCALENDAR');
  return lines.join('\r\n') + '\r\n';
}

// 화면에서 받은 입력({date, endDate, startTime, endTime, allDay ...}) → 저장 형태
function normalizeInput(input) {
  const title = (input.title || '').trim() || '(제목 없음)';
  const rep = REPEAT_TO[input.repeat] ? { repeat: input.repeat, repeatUntil: /^\d{4}-\d{2}-\d{2}$/.test(input.repeatUntil || '') ? input.repeatUntil : '' } : {};
  const lu = input.lunar && Number(input.lunar.m) >= 1 && Number(input.lunar.m) <= 12 && Number(input.lunar.d) >= 1 && Number(input.lunar.d) <= 30
    ? { m: Number(input.lunar.m), d: Number(input.lunar.d), leap: !!input.lunar.leap } : null;
  if (lu) rep.lunar = lu;
  if (input.allDay) {
    const s = input.date;
    const lastDay = input.endDate && input.endDate >= s ? input.endDate : s;
    const d = new Date(lastDay + 'T00:00:00');
    d.setDate(d.getDate() + 1); // 종일 일정 종료일은 다음날(배타적)
    return { title, allDay: true, start: s, end: ymdLocal(d), location: input.location || '', notes: input.notes || '', categoryName: input.categoryName || '', ...rep };
  }
  const zone = TZ.valid(input.tz) ? input.tz : null; // 일정 저장 시간대 (없으면 PC 시간대)
  const at = (d, t) => (zone ? TZ.toInstant(d, t, zone) : new Date(`${d}T${t}:00`));
  const s = at(input.date, input.startTime || '09:00');
  let e = at(input.endDate || input.date, input.endTime || input.startTime || '10:00');
  if (!(e > s)) e = new Date(s.getTime() + 60 * 60 * 1000);
  return { title, allDay: false, start: s.toISOString(), end: e.toISOString(), location: input.location || '', notes: input.notes || '', categoryName: input.categoryName || '', tz: zone || '', ...rep };
}

// ---------- 소스별 처리 ----------
async function fetchIcs(src, start, end) {
  let url = (src.url || '').trim();
  if (!url) throw new Error('iCal 주소가 비어 있습니다');
  if (url.startsWith('webcal://')) url = 'https://' + url.slice(9);
  const res = await fetch(url, { headers: { 'User-Agent': 'DeskCal/0.2' } });
  if (!res.ok) throw new Error(`주소 응답 오류 (${res.status})`);
  return expandIcs(await res.text(), src, start, end);
}

const davClients = new Map();
async function davFor(src, password) {
  const key = `${src.id}|${src.url}|${src.username}|${password}`;
  if (davClients.has(key)) return davClients.get(key);
  const { DAVClient } = await import('tsdav');
  const client = new DAVClient({
    serverUrl: src.url || 'https://caldav.calendar.naver.com',
    credentials: { username: src.username, password },
    authMethod: 'Basic',
    defaultAccountType: 'caldav'
  });
  await client.login();
  const all = await client.fetchCalendars();
  const calendars = all.filter((c) => !c.components || c.components.includes('VEVENT'));
  const entry = { client, calendars };
  davClients.set(key, entry);
  return entry;
}

function pickCalendars(src, calendars) {
  const wanted = (src.calendars || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (!wanted.length) return calendars;
  return calendars.filter((c) => wanted.includes(String(c.displayName)));
}

async function fetchCaldav(src, password, start, end) {
  const { client, calendars } = await davFor(src, password);
  const out = [];
  for (const cal of pickCalendars(src, calendars)) {
    const objs = await client.fetchCalendarObjects({
      calendar: cal,
      timeRange: { start: start.toISOString(), end: end.toISOString() }
    });
    for (const o of objs) {
      if (!o.data) continue;
      try { out.push(...expandIcs(o.data, src, start, end, { writable: true, href: o.url, etag: o.etag })); } catch { /* 깨진 일정 하나는 건너뜀 */ }
    }
  }
  return out;
}

function fetchLocal(src, list, start, end) {
  const out = [];
  for (const base of list) {
    for (const e of expandLocal(base, start, end)) {
      const rec = !!REPEAT_TO[base.repeat];
      out.push({ ...e, id: `${src.id}|${e.uid}|${e.start}`, sourceId: src.id, source: src.name, color: src.color,
        recurring: rec, repeat: rec ? base.repeat : '', repeatUntil: base.repeatUntil || '', lunar: base.lunar || null,
        seriesStart: rec ? base.start : '', seriesEnd: rec ? base.end : '', writable: true });
    }
  }
  return out;
}

async function fetchAll(settings, ctx) {
  const { start, end } = range();
  const events = [];
  const errors = [];
  await Promise.all(settings.sources.filter((s) => s.enabled !== false).map(async (src) => {
    try {
      let got = [];
      if (src.type === 'ics') got = await fetchIcs(src, start, end);
      else if (src.type === 'caldav') got = await fetchCaldav(src, ctx.decrypt(src.password), start, end);
      else if (src.type === 'local') got = fetchLocal(src, ctx.getLocal(), start, end);
      if (src.holiday) got = got.map((e) => ({ ...e, holiday: true, writable: false }));
      events.push(...got);
    } catch (e) {
      errors.push(`${src.name}: ${e.message || e}`);
    }
  }));
  events.sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
  return { events, errors };
}

// ---------- 쓰기 ----------
async function createEvent(src, input, ctx) {
  const data = { ...normalizeInput(input), uid: `${crypto.randomUUID()}@deskcal` };
  if (src.type === 'local') {
    const list = ctx.getLocal(); list.push(data); ctx.saveLocal(list); return data.uid;
  }
  if (src.type === 'caldav') {
    const { client, calendars } = await davFor(src, ctx.decrypt(src.password));
    const targets = pickCalendars(src, calendars);
    const cal = targets.find((c) => String(c.displayName) === src.writeCalendar) || targets[0];
    if (!cal) throw new Error('쓸 수 있는 캘린더를 찾지 못했습니다');
    const r = await client.createCalendarObject({ calendar: cal, filename: `${data.uid.replace(/@.*/, '')}.ics`, iCalString: buildIcs(data) });
    if (r && r.ok === false) throw new Error(`저장 실패 (${r.status})`);
    return data.uid;
  }
  throw new Error('이 캘린더는 읽기 전용입니다');
}

async function updateEvent(src, ev, input, ctx) {
  if (ev.recurring && !ev.repeat) throw new Error('이 반복 일정은 원래 캘린더에서 수정해 주세요');
  const data = { ...normalizeInput(input), uid: ev.uid };
  if (src.type === 'local') {
    const list = ctx.getLocal().map((e) => (e.uid === ev.uid ? data : e)); ctx.saveLocal(list); return;
  }
  if (src.type === 'caldav') {
    const { client } = await davFor(src, ctx.decrypt(src.password));
    const r = await client.updateCalendarObject({ calendarObject: { url: ev.href, etag: ev.etag, data: buildIcs(data) } });
    if (r && r.ok === false) throw new Error(`수정 실패 (${r.status}) — 다른 곳에서 먼저 바뀌었을 수 있어요`);
    return;
  }
  throw new Error('이 캘린더는 읽기 전용입니다');
}

async function deleteEvent(src, ev, ctx) {
  if (ev.recurring && !ev.repeat) throw new Error('이 반복 일정은 원래 캘린더에서 삭제해 주세요');
  if (src.type === 'local') {
    ctx.saveLocal(ctx.getLocal().filter((e) => e.uid !== ev.uid)); return;
  }
  if (src.type === 'caldav') {
    const { client } = await davFor(src, ctx.decrypt(src.password));
    const r = await client.deleteCalendarObject({ calendarObject: { url: ev.href, etag: ev.etag } });
    if (r && r.ok === false) throw new Error(`삭제 실패 (${r.status})`);
    return;
  }
  throw new Error('이 캘린더는 읽기 전용입니다');
}

function forgetClients() { davClients.clear(); }

module.exports = { fetchAll, createEvent, updateEvent, deleteEvent, buildIcs, normalizeInput, expandIcs, forgetClients };
