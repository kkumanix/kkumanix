// 모든 창에 공통으로 테마·글꼴·강조색·글자 크기를 적용
(function () {
  const FONTS = {
    pretendard: "'Pretendard Variable'",
    noto: "'Noto Sans KR Variable'",
    ibm: "'IBM Plex Sans KR'",
    gowun: "'Gowun Dodum'",
    myeongjo: "'Nanum Myeongjo'",
    malgun: "'Malgun Gothic'"
  };
  function ink(hex) {
    const h = String(hex || '#D27A4A').replace('#', '');
    const n = parseInt(h.length === 3 ? h.split('').map((c) => c + c).join('') : h, 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const L = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
    return L > 0.62 ? '#1A1712' : '#FFFFFF';
  }
  let applied = [];
  let apply = function (a) {
    if (!a) return;
    const root = document.documentElement;
    root.dataset.theme = a.theme || 'midnight';
    root.dataset.shape = a.shape || 'square';
    root.style.setProperty('--buddy', String(Math.min(1.8, Math.max(0.5, Number(a.buddySize) || 1)))); // 날짜 옆 친구 크기
    // 모양 계열: 칸 사이를 띄우는지(gap) · 둥근 계열인지(round)
    root.dataset.cells = (a.shape || 'square') === 'square' ? 'line' : 'gap';
    root.dataset.round = ['soft', 'cozy', 'puffy', 'bubble', 'glass'].includes(a.shape) ? '1' : '0';
    // 테마 색 (themes.js) + 직접 고른 배경색·글자색
    if (window.DeskThemes) {
      const r = window.DeskThemes.resolve(a);
      applied.forEach((k) => { if (!(k in r.vars)) root.style.removeProperty(k); });
      Object.entries(r.vars).forEach(([k, v]) => root.style.setProperty(k, v));
      applied = Object.keys(r.vars);
      root.dataset.dark = r.dark ? '1' : '0';
      root.dataset.char = (r.theme && r.theme.char) || '';
    }
    let acc = a.accent || '#D27A4A';
    if (a.theme === 'season-auto' && window.DeskThemes) { const at = window.DeskThemes.actual('season-auto'); if (at) acc = at.accent; } // 계절 자동: 계절마다 강조색도
    root.style.setProperty('--accent', acc);
    // 글자 크기 (달력 스타일 + 고급 설정)
    if (window.DeskThemes && window.DeskThemes.typo) {
      const T = window.DeskThemes.typo(a);
      const set = (k, v) => root.style.setProperty(k, String(v));
      set('--fs-date', T.date); set('--fw-date', T.dateWeight); set('--fs-chip', T.chip); set('--fs-list', T.list);
      set('--fs-clock', T.clock); set('--ic', T.icon); set('--fs-wk', T.weekday); set('--fs-title', T.title);
    }
    root.style.setProperty('--accent-ink', ink(acc));
    const custom = (a.customFont || '').replace(/['";]/g, '').trim();
    const fam = a.font === 'custom' && custom ? `'${custom}'` : (FONTS[a.font] || FONTS.pretendard);
    root.style.setProperty('--font', `${fam}, "Pretendard Variable", "Malgun Gothic", sans-serif`);
    root.style.fontSize = Math.round(16 * Math.min(1.4, Math.max(0.8, a.fontScale || 1)) * 10) / 10 + 'px';
    document.dispatchEvent(new CustomEvent('appearance', { detail: a }));
  }
  // ---- 누름 느낌: 물결 + 딸깍 소리 (설정에서 끌 수 있음) ----
  let last = {}, ac = null;
  function tick() {
    if (last.clickSound === false) return;
    try {
      ac = ac || new AudioContext();
      if (ac.state === 'suspended') ac.resume();
      const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
      o.type = 'triangle';
      o.frequency.setValueAtTime(1700, t); o.frequency.exponentialRampToValueAtTime(650, t + 0.035);
      g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(0.07, t + 0.004); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.05);
      o.connect(g); g.connect(ac.destination); o.start(t); o.stop(t + 0.06);
    } catch { /* 소리를 못 내도 괜찮음 */ }
  }
  function press(el) {
    if (!el) return;
    el.classList.remove('pressfx'); void el.offsetWidth; el.classList.add('pressfx');
    setTimeout(() => el.classList.remove('pressfx'), 420);
    tick();
  }
  document.addEventListener('pointerdown', (e) => {
    if (e.button !== 0) return;
    const el = e.target.closest && e.target.closest('button,[role=button],.chip,label:has(input[type=radio]),label:has(input[type=checkbox])');
    if (el && !el.disabled) press(el);
  }, true);
  // ---- 마우스를 올리면 버튼 이름 보여 주기 (data-tip > aria-label > title) ----
  let tipEl = null, tipT = null, tipFor = null;
  function tipText(el) {
    const t = el.getAttribute('data-tip') || el.getAttribute('aria-label') || el.getAttribute('title') || '';
    if (el.getAttribute('title')) { el.setAttribute('data-tip', t); el.removeAttribute('title'); } // 브라우저 기본 설명과 겹치지 않게
    return t;
  }
  function hideTip() { clearTimeout(tipT); tipFor = null; if (tipEl) tipEl.classList.remove('on'); }
  document.addEventListener('mouseover', (e) => {
    const el = e.target.closest && e.target.closest('button,[role=button],[data-tip]');
    if (el === tipFor) return;
    hideTip();
    if (!el) return;
    const text = tipText(el);
    if (!text || (el.textContent.trim() === text.trim())) return; // 글자가 이미 보이는 버튼은 생략
    tipFor = el;
    tipT = setTimeout(() => {
      if (tipFor !== el || !document.contains(el)) return;
      if (!tipEl) { tipEl = document.createElement('div'); tipEl.className = 'dc-tip'; tipEl.setAttribute('role', 'tooltip'); document.body.appendChild(tipEl); }
      tipEl.textContent = text;
      const r = el.getBoundingClientRect(), w = tipEl.offsetWidth, h = tipEl.offsetHeight;
      let x = r.left + r.width / 2 - w / 2, y = r.bottom + 7;
      x = Math.max(6, Math.min(x, innerWidth - w - 6));
      if (y + h > innerHeight - 6) y = r.top - h - 7;
      tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
      tipEl.classList.add('on');
    }, 320);
  });
  document.addEventListener('mousedown', hideTip, true);
  window.addEventListener('blur', hideTip);
  const apply0 = apply;
  apply = function (a) { if (a) last = a; return apply0(a); };
  window.DeskTheme = { apply, FONTS, press, tick };
  const API = window.deskcal;
  if (API && API.getAppearance) {
    API.getAppearance().then(apply);
    API.onAppearance(apply);
  }
})();
