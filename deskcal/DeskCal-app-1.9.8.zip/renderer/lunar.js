// 음력(한국 단기력) ↔ 양력 변환 — 브라우저·Node의 Intl 달력 데이터(dangi)를 사용
(function (root) {
  let fmt = null;
  function F() {
    if (!fmt) fmt = new Intl.DateTimeFormat('en-u-ca-dangi', { year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'Asia/Seoul' });
    return fmt;
  }
  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  // 양력 날짜(로컬 Y-M-D) → 음력 {y, m, d, leap}
  function toLunar(date) {
    const d = date instanceof Date ? date : new Date(date + 'T12:00:00');
    const noon = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate(), 3)); // 서울 정오
    const parts = F().formatToParts(noon);
    const g = (t) => (parts.find((p) => p.type === t) || {}).value || '';
    const mRaw = g('month');
    return { y: Number(g('relatedYear') || g('year')), m: parseInt(mRaw, 10), d: Number(g('day')), leap: /bis/.test(mRaw) };
  }
  // 음력 y년 m월 d일(윤달 여부) → 양력 'YYYY-MM-DD' (없으면 '')
  const cache = new Map();
  function yearMap(y) {
    if (cache.has(y)) return cache.get(y);
    const m = new Map();
    const d = new Date(y, 0, 15);
    const end = new Date(y + 1, 1, 25);
    for (; d <= end; d.setDate(d.getDate() + 1)) {
      const l = toLunar(d);
      if (l.y !== y) continue;
      const key = `${l.m}-${l.d}-${l.leap ? 1 : 0}`;
      if (!m.has(key)) m.set(key, ymd(d));
    }
    cache.set(y, m);
    return m;
  }
  function toSolar(y, mo, d, leap) {
    const m = yearMap(Number(y));
    let v = m.get(`${mo}-${d}-${leap ? 1 : 0}`);
    if (!v && Number(d) === 30) v = m.get(`${mo}-29-${leap ? 1 : 0}`); // 작은달이면 29일로
    return v || '';
  }
  const label = (l) => `${l.leap ? '윤' : ''}${l.m}.${l.d}`;
  const seollal = (y) => toSolar(y, 1, 1, false);
  const chuseok = (y) => toSolar(y, 8, 15, false);
  const api = { toLunar, toSolar, label, seollal, chuseok };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') root.Lunar = api;
})(typeof window !== 'undefined' ? window : globalThis);
