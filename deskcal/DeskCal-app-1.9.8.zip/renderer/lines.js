// 캐릭터를 누르면 돌아가며 들려주는 말 — 영어 한 줄·명언·응원·감성·꿀팁·알쓸신잡 (+ 가끔 이스터에그)
// 종류를 차례로 돌고, 같은 종류 안에서는 겹치지 않게 섞어서 보여 줘요.
(function (root) {
  const KINDS = [
    { id: 'en', label: '오늘의 영어 한 줄', list: [
      ['The secret of getting ahead is getting started.', '앞서 나가는 비결은 일단 시작하는 거예요.', 'Mark Twain'],
      ['It always seems impossible until it\'s done.', '끝내기 전까지는 늘 불가능해 보여요.', 'Nelson Mandela'],
      ['Well done is better than well said.', '잘 말하는 것보다 잘 해내는 게 낫다.', 'Benjamin Franklin'],
      ['Little by little, one travels far.', '조금씩, 그렇게 멀리 가요.', 'J. R. R. Tolkien'],
      ['Stay hungry, stay foolish.', '늘 갈망하고, 우직하게.', 'Steve Jobs'],
      ['Do what you can, with what you have, where you are.', '지금 있는 곳에서, 가진 것으로, 할 수 있는 걸 해요.', 'Theodore Roosevelt'],
      ['Happiness depends upon ourselves.', '행복은 우리 자신에게 달려 있어요.', 'Aristotle'],
      ['Simplicity is the ultimate sophistication.', '단순함이 가장 높은 세련됨이에요.', 'Leonardo da Vinci'],
      ['The best way out is always through.', '가장 좋은 출구는 언제나 정면 돌파예요.', 'Robert Frost'],
      ['Turn your wounds into wisdom.', '상처를 지혜로 바꾸세요.', 'Oprah Winfrey'],
      ['Act as if what you do makes a difference. It does.', '내 일이 차이를 만든다고 믿고 움직여요. 실제로 그래요.', 'William James'],
      ['Every moment is a fresh beginning.', '모든 순간은 새로운 시작이에요.', 'T. S. Eliot'],
      ['Done is better than perfect.', '완벽보다 완료가 낫다.', '실리콘밸리 격언'],
      ['Slow and steady wins the race.', '느려도 꾸준하면 이겨요.', '이솝 우화'],
      ['Rest is not idleness.', '쉼은 게으름이 아니에요.', 'John Lubbock']
    ] },
    { id: 'ko', label: '명언 한 줄', list: [
      ['천 리 길도 한 걸음부터.', '', '노자'],
      ['아는 것을 안다 하고, 모르는 것을 모른다 하는 것이 아는 것이다.', '', '공자'],
      ['배우고 때때로 익히면 또한 기쁘지 아니한가.', '', '논어'],
      ['오늘 할 수 있는 일을 내일로 미루지 말라.', '', '벤저민 프랭클린'],
      ['너 자신을 알라.', '', '소크라테스'],
      ['고생 끝에 낙이 온다.', '', '속담'],
      ['티끌 모아 태산.', '', '속담'],
      ['구슬이 서 말이라도 꿰어야 보배.', '', '속담'],
      ['시작이 반이다.', '', '아리스토텔레스'],
      ['어제와 똑같이 살면서 다른 미래를 기대하는 건 어리석다.', '', '흔히 아인슈타인의 말로 전해짐'],
      ['행복은 습관이다. 그것을 몸에 지니라.', '', '허버드'],
      ['쉬어 가는 것도 길을 가는 방법이다.', '', '격언']
    ] },
    { id: 'cheer', label: '응원', list: [
      '오늘도 여기까지 온 것만으로 충분히 잘하고 있어요 👏',
      '잠깐 기지개 한 번! 어깨가 가벼워질 거예요 🙆',
      '물 한 잔 마셨어요? 수분 충전도 일이에요 💧',
      '어려운 건 쪼개면 쉬워져요. 제일 작은 것부터 해 봐요',
      '완벽하지 않아도 괜찮아요. 오늘의 70점도 멋져요',
      '실수는 경험치예요. 레벨업 중! ✨',
      '바쁜 날일수록 숨 한 번 크게 쉬어요',
      '당신 덕분에 누군가의 하루가 편해지고 있어요',
      '한 번에 하나씩, 우리 페이스대로 가요 🐢',
      '오늘 끝낸 일 하나만 떠올려 봐요. 잘했어요!',
      '힘든 날엔 맛있는 거 먹기로 해요 🍰',
      '지금 이 순간도 충분히 소중해요'
    ] },
    { id: 'mood', label: '감성 한 줄', list: [
      '창밖 하늘 한 번 보세요. 오늘의 하늘은 오늘만 볼 수 있어요 ☁️',
      '좋아하는 노래 한 곡이면 기분이 달라져요 🎧',
      '따뜻한 차 한 잔의 여유, 어때요? 🍵',
      '천천히 가도 결국 도착해요. 꽃은 서두르지 않으니까요 🌷',
      '오늘의 작은 행복은 무엇이었나요?',
      '바람이 좋은 날엔 마음도 가벼워져요',
      '노을 지는 시간엔 잠깐 멈춰도 좋아요 🌇',
      '고마운 사람에게 짧은 메시지 하나 보내 볼까요? 💌',
      '잘 자는 것도 내일을 위한 준비예요 🌙',
      '계절이 바뀌는 냄새, 느껴지나요? 🍂'
    ] },
    { id: 'tip', label: 'DeskCal 꿀팁', list: [
      '일정은 끌어서 다른 날짜로 옮길 수 있어요 (드래그 앤 드롭)',
      'AI 기능을 써 보세요! 메일을 붙여넣으면 일정만 쏙 골라 줘요 ✨',
      '날짜 칸을 두 번 누르면 그 날짜에 바로 일정을 넣을 수 있어요',
      '메모장 아이콘을 누르면 바탕화면에 메모장이 따로 붙어요 📝',
      '맨 아래 투명도 막대로 배경을 투명하게 만들 수 있어요',
      '단축키 N = 새 일정, R = 동기화, T = 오늘로, M/W = 월·주 보기',
      '일정을 오른쪽 클릭하면 하루·일주일 미루기, 카테고리, 삭제를 바로 할 수 있어요',
      '음력 생신은 일정 창에서 "음력으로 입력" → 매년 반복으로 넣어 보세요',
      '설정 > 꾸미기에서 모양을 9가지로 바꿀 수 있어요',
      '목록과 달력 사이 막대를 끌면 크기를 조절할 수 있어요',
      '"매년", "매주"처럼 반복 일정도 만들 수 있어요 🔁',
      '설정 > 업데이트에서 새 버전을 바로 받을 수 있어요',
      '메모장 ··· 메뉴에서 체크리스트·줄노트로 바꿀 수 있어요',
      '저를 빠르게 세 번 누르면 시즌 친구들이 다시 섞여요 (시즌 컬렉션)'
    ] },
    { id: 'fact', label: '알쓸신잡', list: [
      '꿀은 거의 상하지 않아요. 고대 이집트 무덤에서 나온 꿀도 먹을 수 있었대요 🍯',
      '문어는 심장이 3개예요 🐙',
      '바나나는 식물학적으로 베리(장과)에 속해요 🍌',
      '해달은 잘 때 떠내려가지 않게 서로 손을 잡기도 해요 🦦',
      '금성의 하루는 금성의 1년보다 길어요 🪐',
      '사람 몸의 뼈는 어른 기준 206개예요',
      '번개는 태양 표면보다 몇 배나 뜨거워요 ⚡',
      '기린의 혀는 50cm 가까이 돼요 🦒',
      '12지신의 순서는 쥐·소·호랑이·토끼·용·뱀·말·양·원숭이·닭·개·돼지예요',
      '하품은 전염돼요. 지금 하품하고 싶지 않나요? 🥱',
      '눈송이는 대부분 여섯 갈래 모양이에요 ❄️',
      '펭귄은 무릎이 있어요. 몸 안에 숨어 있을 뿐! 🐧',
      '음력 설과 추석 날짜는 해마다 양력으로 바뀌어요. DeskCal이 계산해 줘요 📅'
    ] }
  ];
  // 이스터에그: 가끔 아무 설명 없이 툭 (목록·설정에는 안 보임)
  const EGG = { id: 'egg', label: '', list: [
    '이하니는 귀여워요! 👶',
    '세상에서 제일 귀여운 건? 이하니요!',
    '이하니 볼은 찹쌀떡보다 말랑해요 🍡',
    '이하니 덕분에 오늘도 힘이 나요 💪'
  ] };
  const store = (k, v) => { try { if (v === undefined) return JSON.parse(localStorage.getItem(k) || 'null'); localStorage.setItem(k, JSON.stringify(v)); } catch { return null; } };
  function nextOf(kind) {
    const key = 'deskcal.lines.' + kind.id;
    let st = store(key);
    if (!st || !Array.isArray(st.order) || st.order.length !== kind.list.length || st.i >= st.order.length) {
      const order = kind.list.map((_, i) => i);
      for (let i = order.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [order[i], order[j]] = [order[j], order[i]]; }
      st = { order, i: 0 };
    }
    const item = kind.list[st.order[st.i]];
    st.i++; store(key, st);
    return item;
  }
  // 다음 말: { kind, label, text, sub, by }
  function next(enabled) {
    if (Math.random() < 0.07) { const t = nextOf(EGG); return { kind: 'egg', label: '', text: t, sub: '', by: '' }; }
    const kinds = KINDS.filter((k) => !enabled || enabled[k.id] !== false);
    if (!kinds.length) return null;
    let i = Number(store('deskcal.lines.k') || 0) % kinds.length;
    store('deskcal.lines.k', i + 1);
    const k = kinds[i], it = nextOf(k);
    if (Array.isArray(it)) return { kind: k.id, label: k.label, text: it[0], sub: it[1] || '', by: it[2] || '' };
    return { kind: k.id, label: k.label, text: it, sub: '', by: '' };
  }
  const api = { KINDS, next };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') root.DeskLines = api;
})(typeof window !== 'undefined' ? window : globalThis);
