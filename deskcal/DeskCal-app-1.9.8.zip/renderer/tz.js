// 시간대 도우미 — 화면(렌더러)과 메인 프로세스 양쪽에서 사용
(function (root) {
  const ZONES = [
    ['Asia/Seoul', '서울'], ['Asia/Tokyo', '도쿄'], ['Asia/Shanghai', '베이징·상하이'], ['Asia/Hong_Kong', '홍콩'],
    ['Asia/Taipei', '타이베이'], ['Asia/Manila', '마닐라'], ['Asia/Singapore', '싱가포르'], ['Asia/Kuala_Lumpur', '쿠알라룸푸르'],
    ['Asia/Jakarta', '자카르타'], ['Asia/Bangkok', '방콕'], ['Asia/Ho_Chi_Minh', '호찌민·하노이'], ['Asia/Kolkata', '인도 (뭄바이·델리)'],
    ['Asia/Dhaka', '다카'], ['Asia/Karachi', '카라치'], ['Asia/Tashkent', '타슈켄트'], ['Asia/Dubai', '두바이·아부다비'],
    ['Asia/Riyadh', '사우디 (리야드)'], ['Asia/Qatar', '카타르 (도하)'], ['Asia/Kuwait', '쿠웨이트'], ['Asia/Baghdad', '바그다드'],
    ['Asia/Tehran', '테헤란'], ['Europe/Istanbul', '이스탄불'], ['Europe/Moscow', '모스크바'], ['Africa/Cairo', '카이로'],
    ['Europe/Berlin', '베를린'], ['Europe/Paris', '파리'], ['Europe/Madrid', '마드리드'], ['Europe/Amsterdam', '암스테르담'],
    ['Europe/London', '런던'], ['UTC', '협정 세계시 (UTC)'], ['America/Sao_Paulo', '상파울루'], ['America/New_York', '뉴욕'],
    ['America/Toronto', '토론토'], ['America/Chicago', '시카고'], ['America/Denver', '덴버'], ['America/Los_Angeles', 'LA·샌프란시스코'],
    ['America/Vancouver', '밴쿠버'], ['Pacific/Honolulu', '하와이'], ['Australia/Sydney', '시드니'], ['Australia/Perth', '퍼스'],
    ['Pacific/Auckland', '오클랜드']
  ];
  const NAME = Object.fromEntries(ZONES);
  const systemZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
  const valid = (tz) => { if (!tz) return false; try { new Intl.DateTimeFormat('en-US', { timeZone: tz }); return true; } catch { return false; } };
  const resolve = (tz) => (tz && tz !== 'system' && valid(tz) ? tz : systemZone());
  const label = (tz) => NAME[tz] || String(tz || '').split('/').pop().replace(/_/g, ' ');

  const fmtCache = new Map();
  function parts(date, tz) {
    let f = fmtCache.get(tz);
    if (!f) {
      f = new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: 'numeric', day: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' });
      fmtCache.set(tz, f);
    }
    const o = {};
    for (const p of f.formatToParts(date)) if (p.type !== 'literal') o[p.type] = +p.value;
    return o; // {year, month, day, hour, minute, second}
  }
  // 그 시간대에서의 '벽시계 시각'을 담은 로컬 Date (달력 계산용)
  function wall(date, tz) {
    const p = parts(date, tz);
    return new Date(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second);
  }
  // 그 순간의 UTC 기준 시차(분)
  function offset(date, tz) {
    const p = parts(date, tz);
    return Math.round((Date.UTC(p.year, p.month - 1, p.day, p.hour % 24, p.minute, p.second) - Math.floor(date.getTime() / 1000) * 1000) / 60000);
  }
  // 'YYYY-MM-DD' + 'HH:MM' (그 시간대 기준) → 실제 순간(Date)
  function toInstant(dateStr, timeStr, tz) {
    const [y, mo, d] = dateStr.split('-').map(Number);
    const [h, mi] = (timeStr || '00:00').split(':').map(Number);
    const guess = Date.UTC(y, mo - 1, d, h, mi);
    let t = guess - offset(new Date(guess), tz) * 60000;
    t = guess - offset(new Date(t), tz) * 60000; // 서머타임 경계 보정
    return new Date(t);
  }
  const offsetLabel = (date, tz) => {
    const m = offset(date, tz), s = m < 0 ? '−' : '+', a = Math.abs(m);
    return `UTC${s}${Math.floor(a / 60)}${a % 60 ? ':' + String(a % 60).padStart(2, '0') : ''}`;
  };
  // 두 시간대 차이 설명: "−6시간"
  const diffLabel = (date, from, to) => {
    const d = offset(date, to) - offset(date, from);
    if (!d) return '같은 시각';
    const s = d < 0 ? '−' : '+', a = Math.abs(d);
    return `${s}${Math.floor(a / 60)}시간${a % 60 ? ' ' + (a % 60) + '분' : ''}`;
  };

  const api = { ZONES, label, systemZone, valid, resolve, parts, wall, offset, toInstant, offsetLabel, diffLabel };
  if (typeof module !== 'undefined') module.exports = api; else root.TZ = api;
})(typeof window !== 'undefined' ? window : globalThis);
